import { n as lessons } from "./lessons-CHNten7h.mjs";
import { x as require_jsx_runtime, y as Link } from "../_libs/@tanstack/react-router+[...].mjs";
import { n as Route } from "./router-Dnv5hbPc.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/aula._id-CTCNAjEh.js
var import_jsx_runtime = require_jsx_runtime();
var FILLS = [
	"var(--color-brand)",
	"var(--color-brand-deep)",
	"var(--color-brand-dark)",
	"var(--color-slice)",
	"var(--color-brand-light)",
	"var(--color-slice-soft)",
	"var(--color-brand-soft)"
];
function money(n) {
	return n.toLocaleString("pt-BR");
}
function ChartView({ chart }) {
	if (chart.type === "donut") return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Donut, {
		labels: chart.labels,
		values: chart.values
	});
	if (chart.type === "funnel") return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Funnel, {
		labels: chart.labels,
		values: chart.values
	});
	if (chart.type === "line") return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Lines, {
		labels: chart.labels,
		series: chart.series
	});
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Bars, {
		labels: chart.labels,
		series: chart.series
	});
}
function legendItems(chart) {
	if (chart.type === "donut") {
		const total = chart.values.reduce((a, b) => a + b, 0) || 1;
		return chart.labels.map((label, i) => ({
			label: `${label} · ${Math.round(chart.values[i] / total * 100)}%`,
			color: FILLS[i % FILLS.length]
		}));
	}
	if (chart.type === "funnel") return chart.labels.map((label, i) => ({
		label: `${label} · ${money(chart.values[i])}`,
		color: FILLS[i % FILLS.length]
	}));
	if (chart.series.length > 1) return chart.series.map((serie, i) => ({
		label: serie.name,
		color: FILLS[i % FILLS.length]
	}));
	return chart.labels.map((label, i) => ({
		label: `${label} · ${money(chart.series[0].data[i])}`,
		color: FILLS[i % FILLS.length]
	}));
}
function Bars({ labels, series }) {
	const flat = series.flatMap((s) => s.data);
	const max = Math.max(...flat, 1);
	const slot = 520 / labels.length;
	const barW = Math.min(36, (slot - 16) / series.length);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("svg", {
		viewBox: "0 0 640 320",
		role: "img",
		children: [[
			0,
			.25,
			.5,
			.75,
			1
		].map((tick) => {
			const y = 28 + (1 - tick) * 220;
			return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("g", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("line", {
				x1: "56",
				x2: "600",
				y1: y,
				y2: y,
				stroke: "var(--color-line)"
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("text", {
				x: "48",
				y: y + 4,
				textAnchor: "end",
				fontSize: "12",
				fill: "var(--color-muted)",
				children: money(Math.round(max * tick))
			})] }, tick);
		}), labels.map((label, i) => {
			const cx = 72 + slot * i + slot / 2;
			return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("g", { children: [series.map((serie, s) => {
				const h = (serie.data[i] ?? 0) / max * 220;
				const x = cx - series.length * barW / 2 + s * barW;
				return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("rect", {
					className: "bar-grow",
					x,
					y: 248 - h,
					width: barW - 4,
					height: h,
					rx: "6",
					fill: FILLS[(series.length > 1 ? s : i) % FILLS.length],
					style: { animationDelay: `${i * .08}s` }
				}, serie.name);
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("text", {
				x: cx,
				y: "276",
				textAnchor: "middle",
				fontSize: "13",
				fill: "var(--color-ink)",
				fontWeight: "600",
				children: label
			})] }, label);
		})]
	});
}
function Lines({ labels, series }) {
	const flat = series.flatMap((s) => s.data);
	const max = Math.max(...flat, 1);
	const min = Math.min(...flat, 0);
	const span = Math.max(max - min, 1);
	const step = labels.length > 1 ? 520 / (labels.length - 1) : 0;
	const x = (i) => 72 + step * i;
	const y = (v) => 248 - (v - min) / span * 210;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("svg", {
		viewBox: "0 0 640 320",
		role: "img",
		children: [
			[
				0,
				.5,
				1
			].map((tick) => {
				const yy = 28 + (1 - tick) * 220;
				const value = min + span * tick;
				return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("g", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("line", {
					x1: "56",
					x2: "600",
					y1: yy,
					y2: yy,
					stroke: "var(--color-line)"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("text", {
					x: "48",
					y: yy + 4,
					textAnchor: "end",
					fontSize: "12",
					fill: "var(--color-muted)",
					children: money(Math.round(value))
				})] }, tick);
			}),
			series.map((serie, s) => {
				const d = serie.data.map((v, i) => `${i === 0 ? "M" : "L"} ${x(i)} ${y(v)}`).join(" ");
				return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("g", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("path", {
					className: "line-draw",
					d,
					fill: "none",
					stroke: FILLS[s % FILLS.length],
					strokeWidth: "4",
					strokeLinejoin: "round",
					strokeLinecap: "round"
				}), serie.data.map((v, i) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("circle", {
					cx: x(i),
					cy: y(v),
					r: "5",
					fill: "white",
					stroke: FILLS[s % FILLS.length],
					strokeWidth: "3"
				}, labels[i]))] }, serie.name);
			}),
			labels.map((label, i) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("text", {
				x: x(i),
				y: "286",
				textAnchor: "middle",
				fontSize: "13",
				fill: "var(--color-ink)",
				fontWeight: "600",
				children: label
			}, label))
		]
	});
}
function Donut({ labels, values }) {
	const total = values.reduce((a, b) => a + b, 0) || 1;
	const r = 78;
	const c = 2 * Math.PI * r;
	let offset = 0;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("svg", {
		viewBox: "0 0 640 320",
		role: "img",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("circle", {
				cx: "320",
				cy: "156",
				r,
				fill: "none",
				stroke: "var(--color-mist)",
				strokeWidth: "28"
			}),
			values.map((value, i) => {
				const len = value / total * c;
				const seg = /* @__PURE__ */ (0, import_jsx_runtime.jsx)("circle", {
					className: "donut-seg",
					cx: "320",
					cy: "156",
					r,
					fill: "none",
					stroke: FILLS[i % FILLS.length],
					strokeWidth: "28",
					strokeDasharray: `${len} ${c - len}`,
					strokeDashoffset: -offset,
					strokeLinecap: "butt",
					transform: "rotate(-90 320 156)",
					style: { animationDelay: `${i * .06}s` }
				}, labels[i]);
				offset += len;
				return seg;
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("text", {
				x: "320",
				y: "152",
				textAnchor: "middle",
				fontSize: "13",
				fill: "var(--color-muted)",
				children: "total"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("text", {
				x: "320",
				y: "174",
				textAnchor: "middle",
				fontSize: "18",
				fontWeight: "700",
				fill: "var(--color-ink)",
				children: money(total)
			})
		]
	});
}
function Funnel({ labels, values }) {
	const max = Math.max(...values, 1);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("svg", {
		viewBox: "0 0 640 320",
		role: "img",
		children: labels.map((label, i) => {
			const w = 160 + values[i] / max * 360;
			const x = (640 - w) / 2;
			const y = 24 + i * 68;
			return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("g", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("rect", {
				className: "bar-grow",
				x,
				y,
				width: w,
				height: "48",
				rx: "12",
				fill: FILLS[i % FILLS.length],
				style: {
					animationDelay: `${i * .1}s`,
					transformOrigin: "center"
				}
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("text", {
				x: "320",
				y: y + 30,
				textAnchor: "middle",
				fontSize: "16",
				fontWeight: "700",
				fill: "white",
				children: [
					label,
					" · ",
					money(values[i])
				]
			})] }, label);
		})
	});
}
function LessonPage() {
	const lesson = Route.useLoaderData();
	const prev = lessons.find((item) => item.id === lesson.id - 1);
	const next = lessons.find((item) => item.id === lesson.id + 1);
	const legend = legendItems(lesson.chart);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("main", {
		className: "lesson",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("header", {
				className: "lesson-hero",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
						className: "kicker",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("i", {}),
							"Aula ",
							String(lesson.id).padStart(2, "0"),
							" de 15",
							lesson.graphic ? " · aula de gráfico" : "",
							" · cerca de 2 horas"
						]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", { children: lesson.title }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "lede",
						children: lesson.lede
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "objs",
				children: lesson.objectives.map((goal, index) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("article", {
					className: "obj",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", { children: ["0", index + 1] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", { children: goal })]
				}, goal))
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("article", {
				className: "prose-card",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", { children: "Nesta aula" }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", { children: lesson.paragraphs[0] }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", { children: lesson.paragraphs[1] })
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("figure", {
				className: "chart-block",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", { children: lesson.chart.title }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "caption",
						children: lesson.chart.caption
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "chart-draw",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ChartView, { chart: lesson.chart })
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("figcaption", {
						className: "legend",
						children: legend.map((item) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("i", {
							className: "swatch",
							style: { background: item.color }
						}), item.label] }, item.label))
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "reads",
				children: lesson.reads.map((title, index) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("article", {
					className: "read",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("strong", { children: title }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", { children: lesson.readText[index] })]
				}, title))
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("aside", {
				className: "task",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", { children: "Tarefa" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", { children: lesson.task })]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("nav", {
				className: "pager",
				"aria-label": "Aulas vizinhas",
				children: [prev ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
					to: "/aula/$id",
					params: { id: String(prev.id) },
					className: "btn ghost",
					children: ["Aula ", String(prev.id).padStart(2, "0")]
				}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
					className: "empty",
					children: "Início do curso"
				}), next ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
					to: "/aula/$id",
					params: { id: String(next.id) },
					className: "btn",
					children: ["Aula ", String(next.id).padStart(2, "0")]
				}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
					to: "/",
					hash: "aulas",
					className: "btn",
					children: "Ver todas"
				})]
			})
		]
	});
}
//#endregion
export { LessonPage as component };
