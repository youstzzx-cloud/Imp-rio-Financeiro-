import { x as require_jsx_runtime, y as Link } from "../_libs/@tanstack/react-router+[...].mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/aula._id-CVzaRlaL.js
var import_jsx_runtime = require_jsx_runtime();
function LessonMissing() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("main", {
		className: "lesson",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", { children: "Aula não encontrada" }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "lede",
				children: "Essa página não faz parte das 15 aulas."
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
				to: "/",
				hash: "aulas",
				className: "btn",
				children: "VOLTAR AO CURSO"
			})
		]
	});
}
//#endregion
export { LessonMissing as errorComponent };
