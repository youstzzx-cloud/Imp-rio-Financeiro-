//#region node_modules/.nitro/vite/services/ssr/assets/lessons-CHNten7h.js
var lessons = [
	{
		id: 1,
		title: "Fundamentos das finanças",
		card: "Receita, despesa, saldo e o primeiro orçamento do mês.",
		lede: "Você vai nomear o que entra, o que sai e o que sobra — mesmo que a renda seja pequena.",
		graphic: false,
		objectives: [
			"Separar receita, despesa, saldo, patrimônio e dívida.",
			"Classificar necessidade e desejo sem transformar a lista em culpa.",
			"Fechar o saldo de um mês com uma conta em reais."
		],
		paragraphs: ["Finanças pessoais são as decisões sobre o dinheiro da sua vida. Não é um dom e não exige planilha sofisticada: é o hábito de olhar os números antes de eles virarem susto. Sem essa base, produto digital, inteligência artificial e Kiwify viram pressa.", "A Marina não existe. Neste exemplo ela recebe R$ 2.800 e gasta R$ 2.460. O saldo é R$ 340. Saldo não é patrimônio. Se ela já deve R$ 1.400, a foto dos bens menos as dívidas continua negativa. E se os R$ 340 saírem no sábado, o mês fecha em zero."],
		chart: {
			type: "bar",
			title: "Um mês da Marina",
			caption: "Exemplo fictício. Receita 2.800, despesa 2.460, saldo 340.",
			labels: [
				"Receita",
				"Despesa",
				"Saldo"
			],
			series: [{
				name: "R$",
				data: [
					2800,
					2460,
					340
				]
			}]
		},
		reads: [
			"Barra alta não é lucro",
			"Saldo é uma conta",
			"Não copie o valor"
		],
		readText: [
			"Receita é o que entrou. Lucro só aparece quando existe um negócio e os custos foram tirados.",
			"Saldo do mês = receita − despesas. Patrimônio = bens − dívidas. São fotos diferentes.",
			"Use o desenho para treinar a leitura. O salário da Marina não é uma média do Brasil."
		],
		task: "Escolha um mês que já terminou. Anote a receita certa e sete potes: moradia, alimentação, transporte, saúde, dívidas, lazer e outros. Feche o saldo no papel."
	},
	{
		id: 2,
		title: "Planejamento do dinheiro",
		card: "Planilha simples, saldo e reserva para imprevisto.",
		lede: "O extrato conta o que já passou. O orçamento decide o que você tenta fazer acontecer.",
		graphic: false,
		objectives: [
			"Montar um fluxo com saldo inicial, entradas e saídas.",
			"Separar reserva de lazer antes de gastar a sobra.",
			"Comparar o plano do mês com o que de fato aconteceu."
		],
		paragraphs: ["Comece pelo que é certo: a receita que você sabe que entra. Lance primeiro necessidades e dívidas já contratadas. O que restar é o teto de desejos mais reserva. Se não restar nada, o teto de desejo é zero até renegociar um compromisso — não até fazer uma dívida nova.", "No exemplo, a Marina abre o mês com R$ 150, recebe R$ 2.800 e sai com R$ 2.460. O saldo final ilustrativo é R$ 490. A reserva desenhada abaixo não é promessa: é a sobra irregular que ela decide guardar, mês a mês."],
		chart: {
			type: "line",
			title: "Reserva se a sobra for irregular",
			caption: "Exemplo fictício, em reais, ao longo de seis meses.",
			labels: [
				"M1",
				"M2",
				"M3",
				"M4",
				"M5",
				"M6"
			],
			series: [{
				name: "Reserva",
				data: [
					200,
					380,
					620,
					800,
					1100,
					1400
				]
			}]
		},
		reads: [
			"Linha sobe, não enriquece",
			"Buraco também ensina",
			"Reserva vem antes"
		],
		readText: [
			"A curva mostra uma decisão repetida, não um rendimento garantido.",
			"Se um mês cair, anote o motivo. O próximo orçamento nasce dessa diferença.",
			"Mesmo R$ 30 separados de propósito já contam. O valor certo não é uma lei."
		],
		task: "Escreva o plano do mês que vem: receita certa, necessidades, dívida, reserva e um teto de lazer. No fim do mês, compare plano e realidade sem rasgar o papel."
	},
	{
		id: 3,
		title: "Juros, inflação e risco",
		card: "Juros simples, compostos, CDI e golpes comuns.",
		lede: "Uma taxa bonita no gráfico não é recomendação de investimento.",
		graphic: false,
		objectives: [
			"Calcular juros simples e compostos num exemplo curto.",
			"Ver como a inflação muda o que o mesmo dinheiro compra.",
			"Reconhecer promessa de rendimento fácil como sinal de golpe."
		],
		paragraphs: ["Juros simples crescem só sobre o valor inicial. Juros compostos crescem sobre o que já rendeu. Em R$ 1.000 a 1% ao mês, hipotético e só para a conta, doze meses dão R$ 1.120 no simples e cerca de R$ 1.127 no composto. A diferença aqui é pequena. Em prazo longo e taxa alta, ela deixa de ser.", "Inflação é a cesta ficando mais cara. R$ 200 parado não acompanha uma cesta que foi a R$ 208. Este curso não escolhe produto de banco, não promete CDI e não substitui a regra oficial do dia. Dinheiro oferecido com pressa, grupo fechado e rendimento fixo alto é motivo para parar, não para transferir."],
		chart: {
			type: "line",
			title: "Simples contra compostos",
			caption: "R$ 1.000 a 1% ao mês, taxa hipotética, doze meses.",
			labels: [
				"0",
				"3",
				"6",
				"9",
				"12"
			],
			series: [{
				name: "Simples",
				data: [
					1e3,
					1030,
					1060,
					1090,
					1120
				]
			}, {
				name: "Compostos",
				data: [
					1e3,
					1030,
					1062,
					1094,
					1127
				]
			}]
		},
		reads: [
			"As duas linhas partem juntas",
			"Taxa de exemplo não é previsão",
			"Desconfie do gráfico milagroso"
		],
		readText: [
			"No começo a diferença quase não aparece. Composto puxa no fim da curva.",
			"Ninguém aqui está dizendo que a sua aplicação renderá 1% ao mês.",
			"Eixo cortado, período escolhido a dedo e print sem fonte não provam ganho."
		],
		task: "Refaça a conta com um valor e uma taxa que você inventar, deixando escrito que é exercício. Se a taxa vier de um anúncio, procure o nome da instituição no site do Banco Central antes de qualquer passo."
	},
	{
		id: 4,
		title: "Empreendedorismo digital",
		card: "Problema real, nicho pequeno e validação barata.",
		lede: "Produto digital bom resolve uma dificuldade concreta de alguém que você consegue descrever.",
		graphic: false,
		objectives: [
			"Trocar “quero vender qualquer coisa” por um problema específico.",
			"Definir quem sente esse problema e onde essa pessoa já está.",
			"Validar com conversa e amostra, sem anúncio e sem empréstimo."
		],
		paragraphs: ["Infoproduto é e-book, guia, planilha ou aula que cabe num arquivo. O nicho lucrativo não é um palpite de internet: é um problema que dói o bastante para alguém pagar um preço de teste. Se você não consegue explicar o problema em uma frase, ainda não há produto.", "Validação barata é ouvir gente real. Conversa não é venda. Lista de interessados é mais forte que um like. Amostra grátis que a pessoa usa é mais forte que a lista. Venda é o único sinal de que o preço fez sentido — e mesmo uma venda não garante a segunda."],
		chart: {
			type: "funnel",
			title: "Força do sinal, não faturamento",
			caption: "Escala ilustrativa: conversa, lista, amostra e venda não são reais.",
			labels: [
				"Conversas",
				"Lista",
				"Amostra",
				"Venda"
			],
			values: [
				1,
				2,
				3,
				5
			]
		},
		reads: [
			"Funil não é caixa",
			"Like é sinal fraco",
			"Comece por um problema"
		],
		readText: [
			"A largura mostra o quanto o sinal é confiável, não quantas pessoas compraram.",
			"Publicação com curtida não valida nicho. Pergunta respondida chega mais perto.",
			"Escreva: quem sofre, com o quê, e o que muda se o material funcionar."
		],
		task: "Escreva três problemas que você já resolveu para alguém. Escolha um. Liste cinco pessoas reais que sentem isso e fale com pelo menos duas antes de abrir a Kiwify."
	},
	{
		id: 5,
		title: "IA para infoprodutos",
		card: "Prompts para rascunhar, nunca para publicar no automático.",
		lede: "A inteligência artificial acelera o primeiro texto. A revisão é o que torna o material seu.",
		graphic: false,
		objectives: [
			"Pedir um rascunho com contexto, público e limite claro.",
			"Conferir fato, tom e originalidade antes de publicar.",
			"Recusar texto que copia curso alheio ou inventa prova."
		],
		paragraphs: ["Um prompt útil diz quem é o leitor, qual problema o material cobre, o que não pode prometer e em que formato entregar. “Escreva um e-book que vende todo dia” produz frase pronta e vazia. “Liste oito erros de orçamento de quem ganha pouco, sem prometer riqueza” produz um rascunho que você consegue revisar.", "Gerar é a parte curta. Revisar é a parte do curso. Troque exemplo genérico por exemplo que você sabe explicar. Apague depoimento que não aconteceu, urgência falsa e número de aluno inventado. Se a ferramenta não cita a fonte, o número não entra no seu material."],
		chart: {
			type: "bar",
			title: "Onde o tempo de verdade vai",
			caption: "Horas ilustrativas: gerar é rápido, revisar é o trabalho.",
			labels: [
				"Pedido",
				"Rascunho",
				"Revisão",
				"Corte"
			],
			series: [{
				name: "Horas",
				data: [
					1,
					1,
					4,
					2
				]
			}]
		},
		reads: [
			"Rascunho não é produto",
			"Número sem fonte sai",
			"A voz tem de ser sua"
		],
		readText: [
			"Se você não leria o texto em voz alta para um amigo, ele ainda não está pronto.",
			"Estatística, taxa e prazo oficial precisam de página que você abriu, não de memória da IA.",
			"Reescreva o trecho que soa como qualquer outro anúncio da internet."
		],
		task: "Peça um sumário de cinco capítulos para o problema escolhido na aula 4. Revise cada título: ele ensina algo ou só promete resultado? Fique com o sumário, não com a promessa."
	},
	{
		id: 6,
		title: "Produto na Kiwify",
		card: "Oferta, preço de teste e cadastro com a documentação aberta.",
		lede: "Império Financeiro não é a Kiwify. Botão, taxa e prazo mudam: a última palavra é a central de ajuda.",
		graphic: false,
		objectives: [
			"Descrever a oferta em uma frase sem renda garantida.",
			"Escolher um preço de teste que você consiga explicar.",
			"Separar preço de vitrine e valor depois da taxa."
		],
		paragraphs: ["Cadastrar é seguir a tela oficial, não um tutorial antigo. Nome do produto, entrega do arquivo, preço e página precisam bater com o que você realmente entrega. Se o botão não for o deste texto, pare e releia o artigo da ajuda. Não chute.", "Preço de teste não é o preço dos seus sonhos. No exemplo, R$ 27 de vitrine não são R$ 27 na conta. Uma taxa ilustrativa de 8,99% mais R$ 2,49 fixos leva o líquido desta conta para cerca de R$ 22 antes de saque, reembolso e imposto. Confira a taxa vigente antes de decidir."],
		chart: {
			type: "bar",
			title: "Preço de vitrine não é líquido",
			caption: "Conta ilustrativa de um produto a R$ 27. Confira a taxa oficial.",
			labels: [
				"Preço",
				"Taxa",
				"Após taxa"
			],
			series: [{
				name: "R$",
				data: [
					27,
					4.92,
					22.08
				]
			}]
		},
		reads: [
			"A barra do meio sai",
			"Uma venda não paga o mês",
			"Tela diferente, pare"
		],
		readText: [
			"Desenhe sempre o que a plataforma fica, não só o preço que o aluno vê.",
			"Este gráfico é uma unidade. Não multiplique por um número de vendas imaginário.",
			"Quando a ajuda oficial divergir da aula, vença a ajuda oficial."
		],
		task: "Escreva a oferta em uma frase e um preço de teste. Ao lado, estime taxa percentual e taxa fixa com o artigo atual da Kiwify aberto. Não publique enquanto a conta não couber numa linha."
	},
	{
		id: 7,
		title: "Página de vendas",
		card: "Texto honesto, estrutura clara e leitura boa no celular.",
		lede: "A página explica o material. Ela não finge escassez, depoimento ou turma fechando.",
		graphic: false,
		objectives: [
			"Ordenar promessa, para quem é, o que tem dentro e o preço.",
			"Escrever para a tela do celular, com frase curta.",
			"Tirar qualquer prova que você não possa mostrar."
		],
		paragraphs: ["Uma página simples tem seis blocos: o problema, para quem serve, o que a pessoa recebe, como usar, o preço e as perguntas que você já ouviu. Cada bloco responde uma dúvida. Nenhum bloco existe para empurrar.", "Copy boa é específica. “Organize um mês com sete potes” é verificável. “Mude de vida em sete dias” não é. Se a página ficar longa no computador e ilegível no telefone, o telefone ganha: é nele que a maior parte das pessoas lê."],
		chart: {
			type: "bar",
			title: "Peso de cada bloco da página",
			caption: "Importância relativa ilustrativa, não um funil de visitas.",
			labels: [
				"Problema",
				"Para quem",
				"Entrega",
				"Preço",
				"Dúvidas"
			],
			series: [{
				name: "Peso",
				data: [
					5,
					4,
					5,
					3,
					4
				]
			}]
		},
		reads: [
			"Peso não é tráfego",
			"Preço aparece inteiro",
			"Dúvida também vende clareza"
		],
		readText: [
			"O gráfico só organiza a página. Ele não mede clique nem conversão.",
			"Esconder taxa, bônus falso ou prazo inventado quebra a confiança que o texto tenta criar.",
			"Responda “serve para quem ainda não investe?” sem envergonhar o leitor."
		],
		task: "Escreva os seis blocos em frases curtas, no celular. Leia em voz alta. Apague toda frase que você não conseguiria sustentar numa conversa."
	},
	{
		id: 8,
		title: "Divulgação orgânica",
		card: "Conteúdo útil em vídeo curto, sem obrigação de aparecer.",
		lede: "Um roteiro honesto vale mais do que spam em grupo ou escassez inventada.",
		graphic: false,
		objectives: [
			"Planejar sete peças que ensinam algo utilizável.",
			"Gravar sem mostrar o rosto, se essa for a sua escolha.",
			"Ler comentário como dúvida, não como prova de venda."
		],
		paragraphs: ["Divulgação orgânica é presença repetida onde o seu leitor já está: vídeo curto, carrossel, resposta a uma pergunta. A peça mostra um pedaço do método — por exemplo, como separar necessidade de desejo — e só no fim aponta o material. Não comece pelo preço.", "Sete dias ilustrativos: um tema por dia, uma peça por dia, descanso no meio se a vida apertar. Comentário “quanto custa?” é interesse, não é venda. Comentário “vou ficar rico?” pede a frase difícil: não, este material não garante renda."],
		chart: {
			type: "bar",
			title: "Uma peça por dia útil",
			caption: "Calendário fictício. A altura é quantidade de peças, não de views.",
			labels: [
				"D1",
				"D2",
				"D3",
				"D4",
				"D5",
				"D6",
				"D7"
			],
			series: [{
				name: "Peças",
				data: [
					1,
					1,
					1,
					0,
					1,
					1,
					1
				]
			}]
		},
		reads: [
			"Altura 1 não é sucesso",
			"O zero também é plano",
			"View não é compra"
		],
		readText: [
			"O gráfico só cobra constância. Alcance alto com mentira não entra na conta.",
			"Dia sem peça pode ser folga marcada, não fracasso.",
			"Não some visualização e chame de faturamento. São unidades diferentes."
		],
		task: "Escreva sete temas, um por dia, cada um com uma frase que a pessoa consegue usar mesmo sem comprar. Grave ou desenhe a primeira peça sem aparecer, se preferir."
	},
	{
		id: 9,
		title: "A primeira venda",
		card: "Sete dias de tentativa. Sem garantia de resultado.",
		lede: "A aula entrega um plano de execução. Ela não assina contrato com o seu faturamento.",
		graphic: false,
		objectives: [
			"Executar uma sequência curta sem anúncio pago.",
			"Responder objeção sem inventar resultado.",
			"Encerrar a semana com o que aconteceu, não com o que você esperava."
		],
		paragraphs: ["Um plano de sete dias pode ser: revisar a página, publicar três peças úteis, falar com as pessoas da aula 4, responder dúvida em público e conferir se o checkout abre no celular. Isso é trabalho. Não é método secreto.", "Se ninguém comprar, o plano não falhou como aula: ele produziu um fato. Preço alto, página confusa, problema fraco ou público errado são hipóteses para testar depois. Empréstimo para “acelerar” não é o próximo passo deste curso."],
		chart: {
			type: "funnel",
			title: "Uma semana fictícia",
			caption: "40 conversas, 12 respostas, 4 amostras, 1 venda. Números inventados.",
			labels: [
				"Conversas",
				"Respostas",
				"Amostras",
				"Venda"
			],
			values: [
				40,
				12,
				4,
				1
			]
		},
		reads: [
			"Uma venda não é meta nacional",
			"O fundo pode ser zero",
			"Não complete com anúncio no crédito"
		],
		readText: [
			"O exemplo existe para você ler um funil, não para copiar a meta de “uma venda certa”.",
			"Zero no último degrau é um resultado possível e honesto.",
			"Dinheiro de aluguel, comida ou dívida não financia teste de anúncio."
		],
		task: "Monte os sete dias no papel com uma ação por dia e um horário que cabe na sua rotina. No oitavo dia, escreva o que foi feito e o que travou, sem maquiar o número."
	},
	{
		id: 10,
		title: "Gestão e lucro real",
		card: "Taxa, reembolso, saque e o que sobra de verdade.",
		lede: "Faturamento é o que passou no checkout. Lucro é o que resta depois das contas.",
		graphic: false,
		objectives: [
			"Tirar taxa, reembolso, anúncio e saque do bruto.",
			"Separar o dinheiro do produto do dinheiro da casa.",
			"Decidir o próximo mês sem chamar faturamento de lucro."
		],
		paragraphs: ["Oito vendas a R$ 27 dão R$ 216 de bruto neste exemplo. Taxas ilustrativas de R$ 34 e um saque de R$ 4 saem antes da sobra. A barra que importa é a última: R$ 178, e mesmo ela ainda não é salário — imposto, anúncio e reembolso não entraram.", "Caixa do produto não paga mercado no automático. Separe um percentual para reinvestimento pequeno (página, ferramenta, tempo) e outro para a sua reserva pessoal. Imposto e nota dependem do seu caso: isso é conversa com contador, não com este curso."],
		chart: {
			type: "bar",
			title: "Do bruto até a sobra",
			caption: "Simulação fictícia. Não é extrato da Kiwify.",
			labels: [
				"Bruto",
				"Taxas",
				"Saque",
				"Sobra"
			],
			series: [{
				name: "R$",
				data: [
					216,
					34,
					4,
					178
				]
			}]
		},
		reads: [
			"Bruto é a barra vaidosa",
			"Sobra é a barra útil",
			"Reinvestimento tem teto"
		],
		readText: [
			"Print de faturamento sem a coluna das taxas engana quem lê e quem posta.",
			"Some de novo no papel: bruto − taxas − saque − anúncio − reembolso.",
			"Reinvestir tudo e viver no aperto não é gestão. É pressa com outro nome."
		],
		task: "Monte uma linha de lucro com os seus números, mesmo que sejam zero vendas. Escreva o que faria com a sobra e o que não misturaria com a conta de casa."
	},
	{
		id: 11,
		title: "Gráfico de barras",
		card: "Como ler receita, despesa e saldo sem se enganar.",
		lede: "A barra compara tamanho. Ela não prova que o mês foi bom.",
		graphic: true,
		objectives: [
			"Ler eixo, unidade e escala antes de opinar.",
			"Perceber quando o eixo cortado aumenta uma diferença pequena.",
			"Reescrever o gráfico com os seus números."
		],
		paragraphs: ["No gráfico de barras, a altura é o valor e a largura não significa nada. Compare só barras que usam a mesma unidade. Receita, despesa e saldo cabem juntas porque todas estão em reais. Misturar reais com “quantidade de pix” no mesmo eixo é erro.", "O golpe visual mais comum é começar o eixo no 2.000, não no zero. A barra do saldo some ou a diferença entre receita e despesa parece um abismo. Neste curso o eixo parte do zero. Se um gráfico de anúncio não mostra o zero, desconfie antes de se emocionar."],
		chart: {
			type: "bar",
			title: "Barras com eixo no zero",
			caption: "Marina, exemplo fictício: 2.800, 2.460 e 340 reais.",
			labels: [
				"Receita",
				"Despesa",
				"Saldo"
			],
			series: [{
				name: "R$",
				data: [
					2800,
					2460,
					340
				]
			}]
		},
		reads: [
			"Ache o zero",
			"Leia a unidade",
			"Saldo baixo não é erro do desenho"
		],
		readText: [
			"Se a menor marca do eixo não é zero, a altura está mentindo sobre a proporção.",
			"R$, %, pessoas e peças não dividem a mesma barra.",
			"A barra curta do saldo está certa: 340 é pequeno perto de 2.800. O desenho só obedece à conta."
		],
		task: "Desenhe três barras com a sua receita, a sua despesa e o seu saldo, começando no zero. Escreva a unidade embaixo. Se o saldo for negativo, marque a barra abaixo da linha e não esconda."
	},
	{
		id: 12,
		title: "Gráfico de linha",
		card: "Como ler a reserva ao longo dos meses.",
		lede: "A linha mostra mudança no tempo. Subida curta não é tendência eterna.",
		graphic: true,
		objectives: [
			"Ler o eixo do tempo da esquerda para a direita.",
			"Distinguir oscilação de uma história que você inventou.",
			"Não projetar o próximo ano com seis pontos fictícios."
		],
		paragraphs: ["Cada ponto é um momento. A ligação entre eles não aconteceu “sozinha”: no exemplo, é a Marina guardando sobras diferentes. Um mês de R$ 180 e outro de R$ 300 fazem a linha mudar de inclinação. Inclinação não é taxa de juros.", "Seis meses não autorizam a frase “vai dobrar”. Para estender a linha você precisaria assumir que a renda, o gasto e a disciplina ficam iguais. A vida não assina isso. Use a linha para perceber se a reserva existe, não para vender o futuro."],
		chart: {
			type: "line",
			title: "Reserva em seis meses",
			caption: "Pontos fictícios: 200, 380, 620, 800, 1.100 e 1.400 reais.",
			labels: [
				"M1",
				"M2",
				"M3",
				"M4",
				"M5",
				"M6"
			],
			series: [{
				name: "Reserva",
				data: [
					200,
					380,
					620,
					800,
					1100,
					1400
				]
			}]
		},
		reads: [
			"Ponto é fato do exemplo",
			"Trecho não é destino",
			"Queda também se desenha"
		],
		readText: [
			"Sem o ponto marcado, a curva é enfeite. Pergunte sempre: o que foi medido?",
			"Não continue o traço além do último mês se os dados acabaram.",
			"Se a reserva for usada num imprevisto, a linha desce. Descer pode ser o motivo de ela existir."
		],
		task: "Marque quatro pontos da sua reserva, mesmo que alguns sejam zero. Ligue com régua. Escreva uma frase só sobre o que já aconteceu, sem prever o mês cinco."
	},
	{
		id: 13,
		title: "Gráfico de rosca",
		card: "Como ver o peso de cada pote do orçamento.",
		lede: "A rosca mostra parte do todo. O todo precisa estar escrito, senão o pedaço mente.",
		graphic: true,
		objectives: [
			"Conferir se as fatias somam a despesa inteira.",
			"Enxergar “outros” gordo como categoria preguiçosa.",
			"Não comparar duas roscas que têm totais diferentes."
		],
		paragraphs: ["As fatias da Marina somam R$ 2.460, a despesa do exemplo, não a receita. Moradia e alimentação ocupam a maior parte. Lazer aparece, mas não explica o mês sozinho. Se você só olha a fatia pequena, escolhe o corte errado e deixa o aluguel intocado — às vezes o aluguel nem deve ser o corte.", "“Outros” com R$ 380 é um aviso. Cabe remédio, impulso e taxa esquecida. A aula de rosca termina quando cada pedaço grande ganha nome. Duas roscas lado a lado só se comparam se os dois totais estão no título. 40% de R$ 1.000 não é 40% de R$ 5.000."],
		chart: {
			type: "donut",
			title: "Potes da despesa",
			caption: "Soma fictícia: R$ 2.460. Não inclui a receita.",
			labels: [
				"Moradia",
				"Alimentação",
				"Transporte",
				"Dívida",
				"Celular",
				"Lazer",
				"Outros"
			],
			values: [
				700,
				650,
				280,
				180,
				50,
				220,
				380
			]
		},
		reads: [
			"Some as fatias",
			"Outros pede nome",
			"Porcentagem sem total engana"
		],
		readText: [
			"700+650+280+180+50+220+380 = 2.460. Se a soma não fecha, o desenho está errado.",
			"Fatia grande sem nome esconde o ajuste que importa.",
			"Escreva o total no título da rosca toda vez que for mostrar a alguém."
		],
		task: "Transforme os sete potes do seu mês numa rosca desenhada à mão. Calcule o percentual de cada um sobre a despesa, não sobre a receita. Dê nome ao que estava em “outros”."
	},
	{
		id: 14,
		title: "Funil da venda",
		card: "Como ler etapas sem transformar tentativa em promessa.",
		lede: "O funil conta pessoas em etapas. Ele não é o extrato do banco.",
		graphic: true,
		objectives: [
			"Nomear cada etapa com um verbo observável.",
			"Aceitar que a base larga e o fundo estreito são normais.",
			"Recusar funil com número de venda garantido."
		],
		paragraphs: ["Uma etapa boa é algo que você consegue contar: conversa feita, resposta recebida, amostra aberta, pagamento confirmado. “Pessoas impactadas” é frouxo demais para decidir o mês. No exemplo fictício, 40 conversas viram 12 respostas, 4 amostras e 1 venda. Nada disso é meta sua.", "Funil de anúncio costuma esconder o custo de cada etapa e mostrar só o fundo bonito. Aqui o desenho existe para você não mentir para si. Se a sua semana terminar em zero vendas, o funil ainda serviu: ele mostra em qual etapa as pessoas pararam."],
		chart: {
			type: "funnel",
			title: "Etapas de uma tentativa",
			caption: "Números inventados para leitura. Não são uma previsão.",
			labels: [
				"Conversas",
				"Respostas",
				"Amostras",
				"Venda"
			],
			values: [
				40,
				12,
				4,
				1
			]
		},
		reads: [
			"Cada faixa é uma etapa",
			"Estreitar não é falha moral",
			"Fundo vazio é dado"
		],
		readText: [
			"Não some as faixas. A mesma pessoa pode estar em mais de uma etapa, e a de baixo já estava na de cima.",
			"A maior parte das conversas não vira compra. O desenho justo mostra isso.",
			"Publique o funil com a palavra “exemplo” ou “a minha semana”, nunca “resultado típico”."
		],
		task: "Desenhe quatro faixas e dê a elas nomes que você consegue contar esta semana. Preencha com zero onde ainda não houve movimento. Não invente a venda para o desenho ficar feliz."
	},
	{
		id: 15,
		title: "Painel do lucro",
		card: "Como mostrar bruto, taxa, saque e sobra no mesmo gráfico.",
		lede: "O painel acaba na sobra. Se a barra do bruto for a única colorida, o painel está incompleto.",
		graphic: true,
		objectives: [
			"Colocar bruto e deduções na mesma unidade.",
			"Não chamar a primeira barra de lucro.",
			"Refazer o painel quando a taxa oficial mudar."
		],
		paragraphs: ["Um painel honesto de uma simulação pequena: R$ 216 brutos, R$ 34 de taxas ilustrativas, R$ 4 de um saque, R$ 178 de sobra antes de imposto, anúncio e reembolso. Se entrar reembolso ou anúncio, a última barra desce. Atualize o desenho. Não deixe o gráfico velho no stories.", "Este painel não é o relatório da Kiwify e não é cálculo fiscal. Ele treina o reflexo de perguntar “o que já foi tirado?”. Quando a central de ajuda mudar taxa ou saque, a aula perde e a tela oficial ganha. Aí você refaz as barras."],
		chart: {
			type: "bar",
			title: "Painel de uma simulação",
			caption: "Bruto 216, taxas 34, saque 4, sobra 178. Tudo fictício.",
			labels: [
				"Bruto",
				"Taxas",
				"Saque",
				"Sobra"
			],
			series: [{
				name: "R$",
				data: [
					216,
					34,
					4,
					178
				]
			}]
		},
		reads: [
			"Quatro barras, uma unidade",
			"Sobra ainda não é salário",
			"Taxa vencida, gráfico vencido"
		],
		readText: [
			"Se uma barra estiver em porcentagem e outra em reais, apague e recomece.",
			"A sobra desta simulação não paga conta nenhuma até você saber o seu imposto e os seus reembolsos.",
			"Data no canto do painel evita que um número antigo circule como se fosse regra."
		],
		task: "Monte o painel com quatro barras: bruto, taxas, outros custos e sobra. Use zero se ainda não vendeu. Escreva a data e a frase “simulação” no título."
	}
];
function getLesson(id) {
	const n = Number(id);
	return lessons.find((lesson) => lesson.id === n);
}
//#endregion
export { lessons as n, getLesson as t };
