import { i as __toESM } from "../_runtime.mjs";
import { n as lessons } from "./lessons-CHNten7h.mjs";
import { q as require_react, x as require_jsx_runtime, y as Link } from "../_libs/@tanstack/react-router+[...].mjs";
import { a as Share2, c as LayoutList, d as FileText, f as ChartPie, g as BadgeCheck, h as Bot, i as Store, l as Funnel, m as ChartLine, o as Scale, p as ChartColumn, r as TrendingUp, s as Lightbulb, t as Wallet, u as Flag } from "../_libs/lucide-react.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/routes-BFv9c1lC.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
var ICONS = [
	Wallet,
	LayoutList,
	TrendingUp,
	Lightbulb,
	Bot,
	Store,
	FileText,
	Share2,
	Flag,
	BadgeCheck,
	ChartColumn,
	ChartLine,
	ChartPie,
	Funnel,
	Scale
];
function Home() {
	const [photo, setPhoto] = (0, import_react.useState)(true);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("main", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
		className: "hero",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "glow g1" }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "glow g2" }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "hero-content",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "hero-text",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("h1", { children: [
							"Construa seu ",
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "green",
								children: "Império Financeiro"
							}),
							" com IA"
						] }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", { children: "Domine suas finanças pessoais, crie infoprodutos com inteligência artificial e prepare sua primeira venda na Kiwify — com aulas escritas e cinco aulas novas só de gráficos." }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "hero-actions",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
								to: "/",
								hash: "aulas",
								className: "btn",
								children: "EXPLORAR AS AULAS"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
								to: "/aula/$id",
								params: { id: "1" },
								className: "btn ghost",
								children: "COMEÇAR PELA AULA 1"
							})]
						})
					]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "hero-image",
					children: [
						photo ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
							src: "https://images.unsplash.com/photo-1559526324-4b87b5e36e44?q=80&w=1200&auto=format&fit=crop",
							alt: "Mesa de trabalho com caderno e planejamento financeiro",
							onError: () => setPhoto(false)
						}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "hero-fallback",
							"aria-hidden": "true",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("svg", {
								viewBox: "0 0 640 480",
								width: "100%",
								height: "100%",
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("rect", {
										x: "70",
										y: "80",
										width: "500",
										height: "320",
										rx: "28",
										fill: "white"
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("rect", {
										x: "100",
										y: "120",
										width: "180",
										height: "18",
										rx: "9",
										fill: "var(--color-brand)"
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("rect", {
										x: "100",
										y: "160",
										width: "120",
										height: "12",
										rx: "6",
										fill: "var(--color-brand-soft)"
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("rect", {
										x: "100",
										y: "210",
										width: "70",
										height: "140",
										rx: "12",
										fill: "var(--color-brand)"
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("rect", {
										x: "186",
										y: "250",
										width: "70",
										height: "100",
										rx: "12",
										fill: "var(--color-brand-dark)"
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("rect", {
										x: "272",
										y: "300",
										width: "70",
										height: "50",
										rx: "12",
										fill: "var(--color-brand-light)"
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("rect", {
										x: "380",
										y: "200",
										width: "150",
										height: "150",
										rx: "75",
										fill: "none",
										stroke: "var(--color-brand)",
										strokeWidth: "28"
									})
								]
							})
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "floating f1",
							children: "Gestão inteligente"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "floating f2",
							children: "Rota para a Kiwify"
						})
					]
				})]
			})
		]
	}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
		className: "section",
		id: "aulas",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "section-title",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", { children: "Conteúdo programático completo" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", { children: "15 aulas planejadas para 30 horas de aprendizado prático. As cinco últimas são aulas de gráficos." })]
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "cards",
			children: lessons.map((lesson, index) => {
				const Icon = ICONS[index] ?? ChartColumn;
				return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
					to: "/aula/$id",
					params: { id: String(lesson.id) },
					className: "card",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "card-top",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "card-icon",
								"aria-hidden": "true",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Icon, { size: 22 })
							}), lesson.graphic ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "tag-grafico",
								children: "Gráfico"
							}) : /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
								className: "card-kicker",
								children: ["Aula ", String(lesson.id).padStart(2, "0")]
							})]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("h3", { children: [
							String(lesson.id).padStart(2, "0"),
							" · ",
							lesson.title
						] }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", { children: lesson.card })
					]
				}, lesson.id);
			})
		})]
	})] });
}
//#endregion
export { Home as component };
