//#region node_modules/.nitro/vite/services/ssr/assets/_tanstack-start-manifest_v-GlpRE3vC.js
var tsrStartManifest = () => ({ routes: {
	__root__: {
		filePath: "/workspace/src/routes/__root.tsx",
		children: ["/", "/aula/$id"],
		preloads: ["/assets/index-Djrzdrch.js"],
		scripts: [{ attrs: {
			type: "module",
			async: !0,
			src: "/assets/index-Djrzdrch.js"
		} }]
	},
	"/": {
		filePath: "/workspace/src/routes/index.tsx",
		children: void 0,
		preloads: ["/assets/routes-CbibKNbg.js"]
	},
	"/aula/$id": {
		filePath: "/workspace/src/routes/aula.$id.tsx",
		children: void 0,
		preloads: ["/assets/aula._id-BQ4VxCI4.js", "/assets/aula._id-nxBukhb5.js"]
	}
} });
//#endregion
export { tsrStartManifest };
