import type { ChartSpec } from "@/data/lessons";

const FILLS = [
  "var(--color-brand)",
  "var(--color-brand-deep)",
  "var(--color-brand-dark)",
  "var(--color-slice)",
  "var(--color-brand-light)",
  "var(--color-slice-soft)",
  "var(--color-brand-soft)",
];

function money(n: number) {
  return n.toLocaleString("pt-BR");
}

export function ChartView({ chart }: { chart: ChartSpec }) {
  if (chart.type === "donut") return <Donut labels={chart.labels} values={chart.values} />;
  if (chart.type === "funnel") return <Funnel labels={chart.labels} values={chart.values} />;
  if (chart.type === "line") return <Lines labels={chart.labels} series={chart.series} />;
  return <Bars labels={chart.labels} series={chart.series} />;
}

export function legendItems(chart: ChartSpec) {
  if (chart.type === "donut") {
    const total = chart.values.reduce((a, b) => a + b, 0) || 1;
    return chart.labels.map((label, i) => ({
      label: `${label} · ${Math.round((chart.values[i] / total) * 100)}%`,
      color: FILLS[i % FILLS.length],
    }));
  }
  if (chart.type === "funnel") {
    return chart.labels.map((label, i) => ({
      label: `${label} · ${money(chart.values[i])}`,
      color: FILLS[i % FILLS.length],
    }));
  }
  if (chart.series.length > 1) {
    return chart.series.map((serie, i) => ({
      label: serie.name,
      color: FILLS[i % FILLS.length],
    }));
  }
  return chart.labels.map((label, i) => ({
    label: `${label} · ${money(chart.series[0].data[i])}`,
    color: FILLS[i % FILLS.length],
  }));
}

function Bars({
  labels,
  series,
}: {
  labels: string[];
  series: { name: string; data: number[] }[];
}) {
  const flat = series.flatMap((s) => s.data);
  const max = Math.max(...flat, 1);
  const groups = labels.length;
  const slot = 520 / groups;
  const barW = Math.min(36, (slot - 16) / series.length);
  return (
    <svg viewBox="0 0 640 320" role="img">
      {[0, 0.25, 0.5, 0.75, 1].map((tick) => {
        const y = 28 + (1 - tick) * 220;
        return (
          <g key={tick}>
            <line x1="56" x2="600" y1={y} y2={y} stroke="var(--color-line)" />
            <text x="48" y={y + 4} textAnchor="end" fontSize="12" fill="var(--color-muted)">
              {money(Math.round(max * tick))}
            </text>
          </g>
        );
      })}
      {labels.map((label, i) => {
        const cx = 72 + slot * i + slot / 2;
        return (
          <g key={label}>
            {series.map((serie, s) => {
              const value = serie.data[i] ?? 0;
              const h = (value / max) * 220;
              const x = cx - (series.length * barW) / 2 + s * barW;
              return (
                <rect
                  key={serie.name}
                  className="bar-grow"
                  x={x}
                  y={248 - h}
                  width={barW - 4}
                  height={h}
                  rx="6"
                  fill={FILLS[(series.length > 1 ? s : i) % FILLS.length]}
                  style={{ animationDelay: `${i * 0.08}s` }}
                />
              );
            })}
            <text x={cx} y="276" textAnchor="middle" fontSize="13" fill="var(--color-ink)" fontWeight="600">
              {label}
            </text>
          </g>
        );
      })}
    </svg>
  );
}

function Lines({
  labels,
  series,
}: {
  labels: string[];
  series: { name: string; data: number[] }[];
}) {
  const flat = series.flatMap((s) => s.data);
  const max = Math.max(...flat, 1);
  const min = Math.min(...flat, 0);
  const span = Math.max(max - min, 1);
  const step = labels.length > 1 ? 520 / (labels.length - 1) : 0;
  const x = (i: number) => 72 + step * i;
  const y = (v: number) => 248 - ((v - min) / span) * 210;
  return (
    <svg viewBox="0 0 640 320" role="img">
      {[0, 0.5, 1].map((tick) => {
        const yy = 28 + (1 - tick) * 220;
        const value = min + span * tick;
        return (
          <g key={tick}>
            <line x1="56" x2="600" y1={yy} y2={yy} stroke="var(--color-line)" />
            <text x="48" y={yy + 4} textAnchor="end" fontSize="12" fill="var(--color-muted)">
              {money(Math.round(value))}
            </text>
          </g>
        );
      })}
      {series.map((serie, s) => {
        const d = serie.data.map((v, i) => `${i === 0 ? "M" : "L"} ${x(i)} ${y(v)}`).join(" ");
        return (
          <g key={serie.name}>
            <path className="line-draw" d={d} fill="none" stroke={FILLS[s % FILLS.length]} strokeWidth="4" strokeLinejoin="round" strokeLinecap="round" />
            {serie.data.map((v, i) => (
              <circle key={labels[i]} cx={x(i)} cy={y(v)} r="5" fill="white" stroke={FILLS[s % FILLS.length]} strokeWidth="3" />
            ))}
          </g>
        );
      })}
      {labels.map((label, i) => (
        <text key={label} x={x(i)} y="286" textAnchor="middle" fontSize="13" fill="var(--color-ink)" fontWeight="600">
          {label}
        </text>
      ))}
    </svg>
  );
}

function Donut({ labels, values }: { labels: string[]; values: number[] }) {
  const total = values.reduce((a, b) => a + b, 0) || 1;
  const r = 78;
  const c = 2 * Math.PI * r;
  let offset = 0;
  return (
    <svg viewBox="0 0 640 320" role="img">
      <circle cx="320" cy="156" r={r} fill="none" stroke="var(--color-mist)" strokeWidth="28" />
      {values.map((value, i) => {
        const len = (value / total) * c;
        const seg = (
          <circle
            key={labels[i]}
            className="donut-seg"
            cx="320"
            cy="156"
            r={r}
            fill="none"
            stroke={FILLS[i % FILLS.length]}
            strokeWidth="28"
            strokeDasharray={`${len} ${c - len}`}
            strokeDashoffset={-offset}
            strokeLinecap="butt"
            transform="rotate(-90 320 156)"
            style={{ animationDelay: `${i * 0.06}s` }}
          />
        );
        offset += len;
        return seg;
      })}
      <text x="320" y="152" textAnchor="middle" fontSize="13" fill="var(--color-muted)">
        total
      </text>
      <text x="320" y="174" textAnchor="middle" fontSize="18" fontWeight="700" fill="var(--color-ink)">
        {money(total)}
      </text>
    </svg>
  );
}

function Funnel({ labels, values }: { labels: string[]; values: number[] }) {
  const max = Math.max(...values, 1);
  return (
    <svg viewBox="0 0 640 320" role="img">
      {labels.map((label, i) => {
        const w = 160 + (values[i] / max) * 360;
        const x = (640 - w) / 2;
        const y = 24 + i * 68;
        return (
          <g key={label}>
            <rect className="bar-grow" x={x} y={y} width={w} height="48" rx="12" fill={FILLS[i % FILLS.length]} style={{ animationDelay: `${i * 0.1}s`, transformOrigin: "center" }} />
            <text x="320" y={y + 30} textAnchor="middle" fontSize="16" fontWeight="700" fill="white">
              {label} · {money(values[i])}
            </text>
          </g>
        );
      })}
    </svg>
  );
}
