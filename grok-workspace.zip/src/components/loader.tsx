import { useEffect, useState } from "react";

export function Loader() {
  const [pct, setPct] = useState(0);
  const [hide, setHide] = useState(false);

  useEffect(() => {
    const reduce = window.matchMedia("(prefers-reduced-motion: reduce)").matches;
    if (reduce) {
      setPct(100);
      setHide(true);
      return;
    }
    let count = 0;
    const id = window.setInterval(() => {
      count = Math.min(100, count + 5);
      setPct(count);
      if (count >= 100) {
        window.clearInterval(id);
        window.setTimeout(() => setHide(true), 280);
      }
    }, 20);
    return () => window.clearInterval(id);
  }, []);

  return (
    <div className={hide ? "loader hide" : "loader"} role="status" aria-live="polite" aria-hidden={hide}>
      <h1>Império Financeiro</h1>
      <div className="bar" aria-hidden="true">
        <span style={{ width: `${pct}%` }} />
      </div>
      <div className="percent">{pct}%</div>
    </div>
  );
}
