import { Link } from "@tanstack/react-router";

export function Navbar() {
  return (
    <header className="navbar">
      <Link to="/" className="logo">
        Império Financeiro
      </Link>
      <Link to="/" hash="aulas" className="btn">
        VER CURSO
      </Link>
    </header>
  );
}

export function Footer() {
  return (
    <footer className="site-footer">
      <p>© 2026 Império Financeiro — material educacional independente.</p>
      <p>
        Não é a Kiwify, o Banco Central nem a Receita Federal. Não promete renda, venda ou rentabilidade.
        Personagens e gráficos usam números fictícios.
      </p>
    </footer>
  );
}
