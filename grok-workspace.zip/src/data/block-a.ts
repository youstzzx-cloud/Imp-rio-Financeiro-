import type { Lesson } from "./types";

export const lessonsA: Lesson[] = [
  {
    id: 1,
    title: "Fundamentos das finanças",
    card: "Receita, despesa, saldo e o primeiro orçamento do mês.",
    lede: "Você vai nomear o que entra, o que sai e o que sobra — mesmo que a renda seja pequena.",
    graphic: false,
    duration: "2h30",
    objectives: [
      "Separar receita, despesa, saldo, patrimônio e dívida.",
      "Classificar necessidade e desejo sem transformar a lista em culpa.",
      "Fechar o saldo de um mês com uma conta em reais.",
    ],
    paragraphs: [
      "Finanças pessoais são as decisões sobre o dinheiro da sua vida. Não é um dom e não exige planilha sofisticada: é o hábito de olhar os números antes de eles virarem susto. Sem essa base, produto digital, inteligência artificial e Kiwify viram pressa.",
      "A Marina não existe. Neste exemplo ela recebe R$ 2.800 e gasta R$ 2.460. O saldo é R$ 340. Saldo não é patrimônio. Se ela já deve R$ 1.400, a foto dos bens menos as dívidas continua negativa. E se os R$ 340 saírem no sábado, o mês fecha em zero.",
    ],
    plan: [
      { min: "15 min", text: "Leia a abertura e copie as cinco palavras no caderno: receita, despesa, saldo, patrimônio, dívida." },
      { min: "30 min", text: "Separe um mês que já terminou. Abra extrato e anote só o que entrou de renda, sem empréstimo." },
      { min: "25 min", text: "Agrupe as saídas em sete potes e some. Confira a conta duas vezes." },
      { min: "20 min", text: "Leia o gráfico da Marina e reescreva as três barras com os seus números, eixo no zero." },
      { min: "45 min", text: "Classifique cada pote em necessidade, desejo ou dívida já assumida. Escreva uma frase por pote." },
      { min: "15 min", text: "Feche o saldo, responda as conferências e deixe a tarefa marcada para amanhã se o extrato não estiver completo." },
    ],
    sections: [
      {
        title: "As cinco palavras que não podem se misturar",
        paragraphs: [
          "Receita é dinheiro que entra por um motivo combinado: salário, freela, pensão recebida, venda. Empréstimo que cai na conta também aumenta o saldo do banco, mas não é receita. É dívida nova. Anotar os dois no mesmo bolo é o erro que faz o mês parecer folgado.",
          "Despesa é o que sai, no Pix, no débito ou em dinheiro vivo. Lucro só fica claro quando existe um negócio: se um bolo custou R$ 18 e foi vendido a R$ 30, o lucro bruto daquela unidade é R$ 12, antes de gás, embalagem e taxa. Salário não é lucro. Faturamento de uma venda futura também não.",
          "Patrimônio líquido é o que você tem de valor menos o que você deve. R$ 900 na conta e R$ 1.400 de dívida dão − R$ 500 nesse recorte. Não é falha moral. É um número. Saldo do mês é outro filme: receita menos despesas daqueles trinta dias.",
        ],
      },
      {
        title: "Para onde o dinheiro foi",
        paragraphs: [
          "A maioria sabe o salário de cabeça e subestima o resto. O resto mora em débito automático, aplicativo de comida e dinheiro vivo. Escolha um mês encerrado. Mês corrente engana, porque o aluguel pode cair só no dia 8.",
          "Sete potes bastam: moradia, alimentação, transporte, saúde, dívidas, lazer e outros. Se um gasto não cabe, vai para outros e na semana seguinte ganha nome. Outros gordo é categoria preguiçosa, não é destino.",
          "Ganhando pouco, o método é o mesmo. Muda o tamanho da folga, não o direito de enxergar. Uma renda de R$ 1.400 também pode ser escrita. O que não pode é copiar um orçamento de internet feito para outra renda e chamar o resultado de fracasso.",
        ],
      },
      {
        title: "Necessidade, desejo e meta que cabe",
        paragraphs: [
          "Necessidade, aqui, é o que mantém saúde, moradia segura, trabalho e um mínimo de vida social. Desejo é o que pode esperar ou encolher sem quebrar essas bases. A fronteira não é universal. Remédio contínuo é necessidade. O terceiro delivery da semana, para muita gente, é desejo. Uber de madrugada depois do turno pode ser necessidade.",
          "A pergunta operacional é: se eu tirar isto por trinta dias, o que quebra de verdade? Se a resposta for nada essencial, é candidato a ajuste. Não use a palavra fútil para se xingar.",
          "Meta realista tem valor, prazo, fonte da sobra e motivo. Quero ficar rico não tem nenhuma das quatro. Guardar R$ 80 por mês durante quatro meses para uma conta de luz atrasada tem. Se o saldo é R$ 80, meta de guardar R$ 400 é ficção. Ou a despesa cai, ou a receita sobe, ou a meta encolhe. Cartão para tapar o buraco empurra a meta para a coluna da dívida.",
        ],
      },
      {
        title: "O primeiro orçamento",
        paragraphs: [
          "Orçamento é plano, feito no início do mês, de quanto pode sair em cada pote. Extrato conta o que já aconteceu. A ordem é: receita certa, necessidades e dívidas já contratadas, subtração, reserva antes do desejo, comparação no fim do mês sem rasgar o papel.",
          "No mês fictício da Marina: aluguel R$ 700, mercado R$ 650, transporte R$ 280, parcela R$ 180, celular R$ 50, lanche e streaming R$ 220, farmácia e outros R$ 380. Soma R$ 2.460. Receita R$ 2.800 menos isso é R$ 340. O lanche sozinho é R$ 220. Cortar metade liberaria R$ 110 sem mexer em aluguel nem em comida básica. É escolha, não ordem.",
          "Nada nesta aula pede que você invista, empreste ou compre anúncio. O resultado esperado é um orçamento escrito. Negativação, pensão, doença ou juros muito altos pedem profissional habilitado. O papel desta aula é o mapa, não a sentença.",
        ],
      },
    ],
    chart: {
      type: "bar",
      title: "Um mês da Marina",
      caption: "Exemplo fictício. Receita 2.800, despesa 2.460, saldo 340.",
      labels: ["Receita", "Despesa", "Saldo"],
      series: [{ name: "R$", data: [2800, 2460, 340] }],
    },
    reads: ["Barra alta não é lucro", "Saldo é uma conta", "Não copie o valor"],
    readText: [
      "Receita é o que entrou. Lucro só aparece quando existe um negócio e os custos foram tirados.",
      "Saldo do mês = receita − despesas. Patrimônio = bens − dívidas. São fotos diferentes.",
      "Use o desenho para treinar a leitura. O salário da Marina não é uma média do Brasil.",
    ],
    mistakes: [
      "Chamar salário de lucro e achar que sobrou dinheiro para anúncio.",
      "Contar empréstimo como receita porque caiu na conta.",
      "Fazer o orçamento do mês que ainda não acabou e concluir que está tudo bem.",
    ],
    practice: [
      "Escreva a receita certa de um mês encerrado. Risque qualquer valor que seja empréstimo.",
      "Liste os sete potes com valor. Some na calculadora e de novo no papel.",
      "Marque N, D ou dívida em cada linha. Não deixe linha sem marca.",
      "Calcule o saldo. Se for negativo, escreva uma frase: o que é necessidade que não dá para cortar esta semana e o que é desejo.",
      "Guarde o papel. A aula 2 começa exatamente dele.",
    ],
    checks: [
      { q: "Saldo de R$ 340 significa que a Marina tem R$ 340 de patrimônio?", a: "Não. Saldo é o filme do mês. Patrimônio é bens menos dívidas. Ela pode ter saldo positivo e patrimônio negativo." },
      { q: "Pix de empréstimo entra na receita?", a: "Não. Entra como dívida nova. Receita é renda combinada, não dinheiro emprestado." },
      { q: "Qual é a conta do saldo?", a: "Receita do mês menos despesas do mês. No exemplo, 2.800 − 2.460 = 340." },
    ],
    task: "Termine o orçamento escrito mesmo que falte um comprovante. Onde faltar, escreva estimativa e um ponto de interrogação. Amanhã você troca o chute pelo extrato. Não passe para a aula 2 com a folha em branco.",
  },
  {
    id: 2,
    title: "Planejamento do dinheiro",
    card: "Planilha simples, saldo e reserva para imprevisto.",
    lede: "O extrato conta o que já passou. O orçamento decide o que você tenta fazer acontecer.",
    graphic: false,
    duration: "2h30",
    objectives: [
      "Montar um fluxo com saldo inicial, entradas e saídas.",
      "Separar reserva de lazer antes de gastar a sobra.",
      "Comparar o plano do mês com o que de fato aconteceu.",
    ],
    paragraphs: [
      "Comece pelo que é certo: a receita que você sabe que entra. Lance primeiro necessidades e dívidas já contratadas. O que restar é o teto de desejos mais reserva. Se não restar nada, o teto de desejo é zero até renegociar um compromisso — não até fazer uma dívida nova.",
      "No exemplo, a Marina abre o mês com R$ 150, recebe R$ 2.800 e sai com R$ 2.460. O saldo final ilustrativo é R$ 490. A reserva desenhada no gráfico não é promessa de rendimento: é a sobra irregular que ela decide guardar.",
    ],
    plan: [
      { min: "15 min", text: "Reabra o orçamento da aula 1. Se estiver em branco, faça a versão curta agora antes de seguir." },
      { min: "30 min", text: "Monte a linha do tempo do mês: saldo inicial, cada entrada, cada saída grande, saldo final." },
      { min: "25 min", text: "Decida a reserva antes do lazer. Escreva o valor, mesmo que seja R$ 20." },
      { min: "20 min", text: "Leia a linha da reserva e anote o que faria a curva cair de propósito, tipo um conserto." },
      { min: "45 min", text: "Preencha o plano do mês que vem, pote por pote, com teto e não com desejo solto." },
      { min: "15 min", text: "Marque no calendário o dia em que você vai comparar plano e realidade." },
    ],
    sections: [
      {
        title: "Saldo inicial não é detalhe",
        paragraphs: [
          "Muita planilha começa na receita e esquece o que já estava na conta. Se a Marina começa com R$ 150, recebe R$ 2.800 e gasta R$ 2.460, o saldo final é 150 + 2.800 − 2.460 = R$ 490. Sem o saldo inicial, ela acharia que terminou com R$ 340 e tomaria uma decisão com o número errado.",
          "Saldo inicial também revela o que você não lançou. Se a conta do banco não bate com o papel, falta lançamento. Não falta força de vontade. Procure o Pix sem nome, a tarifa e o dinheiro vivo.",
          "Dinheiro que está na conta mas já tem dono — aluguel que vence amanhã, parcela que cai depois de amanhã — não é sobra. Marque esses compromissos antes de chamar qualquer valor de livre.",
        ],
      },
      {
        title: "Reserva antes do desejo",
        paragraphs: [
          "Reserva de imprevisto não é investimento e não é o tênis novo. É o dinheiro que impede um conserto pequeno de virar dívida. O valor certo não é uma lei. Muita gente usa como bússola ter alguns meses de despesas essenciais. Quem está no primeiro mês pode mirar uma conta de luz.",
          "A decisão é a ordem. Primeiro o teto da reserva, mesmo R$ 30. Depois o teto do lazer. Se você inverter, a reserva vira o que sobrou do sábado, e em geral não sobra.",
          "No gráfico, a reserva fictícia sobe de forma irregular: 200, 380, 620, 800, 1.100, 1.400. Os aportes não são iguais. A linha só existe porque a decisão se repetiu. Um mês sem aporte não apaga os anteriores. Um mês em que o dinheiro sai para um imprevisto real também não é fracasso: era para isso que a reserva existia.",
        ],
      },
      {
        title: "Plano contra realidade",
        paragraphs: [
          "No fim do mês, copie duas colunas: planejado e acontecido. A diferença ensina o próximo orçamento. Se a alimentação estourou R$ 80, o próximo teto ou sobe com consciência ou o cardápio muda. Rasgar a folha porque errou só garante que o erro se repita sem nome.",
          "Não ajuste o plano no meio do mês para ele ficar bonito. O plano é a intenção. O extrato é o fato. Os dois precisam continuar visíveis.",
          "Se o saldo final for menor do que o inicial mais a receita menos as despesas que você anotou, ainda há fuga. Volte aos potes. Quase sempre o furo está em outros ou em dinheiro vivo.",
        ],
      },
      {
        title: "Uma folha que cabe no celular",
        paragraphs: [
          "Você não precisa de sistema. Uma nota com oito linhas resolve: saldo inicial, receita, seis potes de saída, reserva, lazer, saldo final. Se quiser planilha, as mesmas linhas viram colunas. O formato não salva quem não lança.",
          "Lance no dia, não no fim do mês. Dois minutos depois do mercado evitam a reconstrução de memória. Se esquecer um dia, lance no seguinte sem drama e sem apagar a semana.",
          "Esta aula ainda não pede produto digital. Se a reserva do mês que vem é zero, anúncio e curso pago ficam fora. O império que começa furando a conta de casa não é império. É pressa.",
        ],
      },
    ],
    chart: {
      type: "line",
      title: "Reserva se a sobra for irregular",
      caption: "Exemplo fictício, em reais, ao longo de seis meses.",
      labels: ["M1", "M2", "M3", "M4", "M5", "M6"],
      series: [{ name: "Reserva", data: [200, 380, 620, 800, 1100, 1400] }],
    },
    reads: ["Linha sobe, não enriquece", "Buraco também ensina", "Reserva vem antes"],
    readText: [
      "A curva mostra uma decisão repetida, não um rendimento garantido.",
      "Se um mês cair, anote o motivo. O próximo orçamento nasce dessa diferença.",
      "Mesmo R$ 30 separados de propósito já contam. O valor certo não é uma lei.",
    ],
    mistakes: [
      "Gastar a sobra no sábado e chamar de falha de caráter o que foi falta de teto.",
      "Esconder compromisso que já tem data dentro do saldo livre.",
      "Trocar o plano no dia 20 para o papel coincidir com o extrato.",
    ],
    practice: [
      "Calcule saldo final = saldo inicial + receitas − despesas, com os seus números.",
      "Escreva o teto da reserva do mês que vem antes de escrever o teto do lazer.",
      "Monte as oito linhas da nota no celular.",
      "Escolha o dia do mês em que a comparação vai acontecer e coloque um alarme.",
      "Se não houver sobra, escreva isso com todas as letras. Zero também é um plano.",
    ],
    checks: [
      { q: "Qual é o saldo final da Marina se ela começa com R$ 150?", a: "150 + 2.800 − 2.460 = R$ 490. Sem o saldo inicial a conta mente." },
      { q: "Reserva que desce num conserto foi desperdício?", a: "Não. Se o conserto era imprevisto real, a reserva cumpriu a função." },
      { q: "O que vem primeiro, lazer ou reserva?", a: "A reserva, mesmo pequena. O lazer recebe teto com o que restar." },
    ],
    task: "Deixe o plano do mês que vem escrito por completo: saldo que você espera abrir, receita certa, potes, reserva e lazer. Não use número de um influenciador. Use o que a aula 1 mostrou.",
  },
  {
    id: 3,
    title: "Juros, inflação e risco",
    card: "Juros simples, compostos, inflação e golpes comuns.",
    lede: "Uma taxa bonita no gráfico não é recomendação de investimento.",
    graphic: false,
    duration: "2h30",
    objectives: [
      "Calcular juros simples e compostos num exemplo curto.",
      "Ver como a inflação muda o que o mesmo dinheiro compra.",
      "Reconhecer promessa de rendimento fácil como sinal de golpe.",
    ],
    paragraphs: [
      "Juros simples crescem só sobre o valor inicial. Juros compostos crescem sobre o que já rendeu. Em R$ 1.000 a 1% ao mês, hipotético e só para a conta, doze meses dão R$ 1.120 no simples e cerca de R$ 1.127 no composto. A diferença aqui é pequena. Em prazo longo e taxa alta, ela deixa de ser.",
      "Inflação é a cesta ficando mais cara. R$ 200 parado não acompanha uma cesta que foi a R$ 208. Este curso não escolhe produto de banco, não promete CDI e não substitui a regra oficial do dia.",
    ],
    plan: [
      { min: "20 min", text: "Copie as duas fórmulas e calcule o exemplo de R$ 1.000 a 1% no papel, mês a mês, até o mês 3." },
      { min: "25 min", text: "Termine os doze meses na calculadora. Anote simples, compostos e a diferença." },
      { min: "20 min", text: "Refaça com uma taxa e um valor inventados por você. Escreva hipotético no topo da folha." },
      { min: "20 min", text: "Leia o trecho da inflação e ache um item real que você compra todo mês. Compare o preço de hoje com o de um ano atrás, se souber." },
      { min: "40 min", text: "Liste três anúncios ou frases que você já viu prometendo rendimento. Marque os sinais de golpe da aula." },
      { min: "25 min", text: "Leia o gráfico, responda as conferências e escreva o que você não vai fazer com essa conta." },
    ],
    sections: [
      {
        title: "Simples e compostos na mão",
        paragraphs: [
          "Juros simples: montante = capital × (1 + taxa × tempo). Com taxa de 1% ao mês, use 0,01, não 1. Em doze meses: 1.000 × (1 + 0,01 × 12) = 1.000 × 1,12 = R$ 1.120.",
          "Juros compostos: montante = capital × (1 + taxa) elevado ao tempo. 1.000 × (1,01)¹² dá aproximadamente R$ 1.126,83. A diferença para o simples, nesse prazo curto e nessa taxa baixa, é de poucos reais. O desenho serve para você ver o mecanismo, não para se animar.",
          "Se a taxa vier ao ano e o tempo estiver em meses, não misture. Doze meses a 1% ao mês não é a mesma coisa que 12% ao ano compostos. Pare e converta antes de concluir.",
        ],
      },
      {
        title: "O que a inflação faz com o dinheiro parado",
        paragraphs: [
          "Se uma cesta custava R$ 200 e passa a custar R$ 208, o mesmo dinheiro compra menos. Não é que a nota encolheu no bolso. É que o preço andou. Quem guarda sem nenhum rendimento perde poder de compra, mas isso não autoriza correr para a primeira aplicação que aparece no anúncio.",
          "CDI, poupança, Tesouro e fundo têm regras, impostos e riscos diferentes. Esta aula não recomenda nenhum. Quando a decisão for real, leia o documento do dia no site da instituição e, se o valor for grande para a sua vida, fale com alguém habilitado.",
          "Dívida cara quase sempre ganha de aplicação modesta. Não faz sentido comemorar 1% hipotético ao mês enquanto o rotativo do cartão come muito mais. A ordem do curso continua: enxergar, reservar, não empilhar juros. Produto de investimento vem depois, fora desta aula.",
        ],
      },
      {
        title: "Como um gráfico mente",
        paragraphs: [
          "Eixo que não começa no zero faz uma diferença pequena parecer abismo. Período escolhido a dedo mostra só a subida. Print sem fonte, sem data e sem o que foi descontado não é prova.",
          "Duas linhas que partem juntas, como no exemplo, ensinam paciência: no começo o composto mal se separa do simples. Quem vende pressa precisa de um gráfico que exploda no primeiro mês. Desconfie desse desenho.",
          "Números redondos demais, sem casa decimal e sem fórmula, costumam ser decoração. Se você não consegue refazer a conta, você não entendeu a oferta. E se não entendeu, não transfere.",
        ],
      },
      {
        title: "Sinais para parar",
        paragraphs: [
          "Pare se pedirem pressa, grupo fechado, rendimento fixo alto, pix para pessoa física, ou garantia de que não tem como perder. Pare se desestimularem você a ler o contrato. Pare se o explicador ficar irritado com a pergunta sobre taxa e prazo.",
          "Pirâmide e aposta disfarçada de investimento usam a linguagem de comunidade e de quem chegou primeiro. Chegar primeiro não é análise. É fila.",
          "Dinheiro de aluguel, comida, remédio ou parcela não entra em teste. A aula de gráfico, mais adiante, volta nisso: desenho bonito não muda a origem do dinheiro.",
        ],
      },
    ],
    chart: {
      type: "line",
      title: "Simples contra compostos",
      caption: "R$ 1.000 a 1% ao mês, taxa hipotética, doze meses.",
      labels: ["0", "3", "6", "9", "12"],
      series: [
        { name: "Simples", data: [1000, 1030, 1060, 1090, 1120] },
        { name: "Compostos", data: [1000, 1030, 1062, 1094, 1127] },
      ],
    },
    reads: ["As duas linhas partem juntas", "Taxa de exemplo não é previsão", "Desconfie do gráfico milagroso"],
    readText: [
      "No começo a diferença quase não aparece. Composto puxa no fim da curva.",
      "Ninguém aqui está dizendo que a sua aplicação renderá 1% ao mês.",
      "Eixo cortado, período escolhido a dedo e print sem fonte não provam ganho.",
    ],
    mistakes: [
      "Usar 1 no lugar de 0,01 e achar que o dinheiro multiplicou por magia.",
      "Tratar o exemplo de 1% ao mês como meta de investimento real.",
      "Pagar rotativo caro enquanto separa dinheiro para uma aplicação que você não entende.",
    ],
    practice: [
      "Calcule simples e compostos para R$ 500 a 2% ao mês durante 6 meses. Escreva hipotético.",
      "Anote a diferença. Diga em uma frase se ela é grande ou pequena nesse prazo.",
      "Escolha um preço que você paga todo mês e escreva o que aconteceria se ele subisse 4%.",
      "Liste dois sinais de golpe que você já viu e a frase que usaria para recusar.",
      "Escreva: esta conta não é ordem para investir.",
    ],
    checks: [
      { q: "Quanto é R$ 1.000 a juros simples de 1% ao mês em 12 meses?", a: "R$ 1.120. A conta é 1.000 × (1 + 0,01 × 12)." },
      { q: "Por que a diferença para o composto é pequena nesse exemplo?", a: "Porque a taxa é baixa e o prazo é curto. O mecanismo aparece; a fortuna, não." },
      { q: "Inflação de uma cesta de R$ 200 para R$ 208 significa o quê?", a: "O mesmo dinheiro compra menos. Não é recomendação de produto financeiro." },
    ],
    task: "Entregue uma folha com as duas contas, a frase hipotético no topo, um exemplo de preço do seu mês e três sinais de golpe que você se compromete a recusar. Sem isso, a aula não acabou.",
  },
  {
    id: 4,
    title: "Empreendedorismo digital",
    card: "Problema real, nicho pequeno e validação barata.",
    lede: "Produto digital bom resolve uma dificuldade concreta de alguém que você consegue descrever.",
    graphic: false,
    duration: "2h30",
    objectives: [
      "Trocar uma ideia vaga por um problema específico.",
      "Definir quem sente esse problema e onde essa pessoa já está.",
      "Validar com conversa e amostra, sem anúncio e sem empréstimo.",
    ],
    paragraphs: [
      "Infoproduto é e-book, guia, planilha ou aula que cabe num arquivo. O nicho não é um palpite de internet: é um problema que dói o bastante para alguém pagar um preço de teste. Se você não consegue explicar o problema em uma frase, ainda não há produto.",
      "Validação barata é ouvir gente real. Conversa não é venda. Lista de interessados é mais forte que um like. Amostra que a pessoa usa é mais forte que a lista. Venda é o sinal de que o preço fez sentido — e uma venda não garante a segunda.",
    ],
    plan: [
      { min: "20 min", text: "Escreva dez problemas que você já ajudou alguém a resolver, sem filtrar." },
      { min: "25 min", text: "Corte até três. Para cada um, escreva quem sofre, onde essa pessoa está e o que muda se o material funcionar." },
      { min: "20 min", text: "Escolha um. Descreva o leitor em dez linhas concretas: rotina, restrição de dinheiro, o que ele já tentou." },
      { min: "20 min", text: "Leia o funil. Ele mede força de sinal, não faturamento. Não invente números de venda." },
      { min: "50 min", text: "Fale com duas pessoas reais ou escreva as mensagens e envie. Anote as palavras que elas usam, não as suas." },
      { min: "15 min", text: "Decida se o problema continua de pé. Se ninguém reconhecer, troque o problema, não aumente o preço." },
    ],
    sections: [
      {
        title: "Problema em uma frase",
        paragraphs: [
          "Frase fraca: quero vender um e-book de finanças. Frase forte: quero ajudar quem ganha pouco e não sabe para onde foi o salário a fechar um mês em sete potes, sem prometer investimento. A segunda cabe num produto. A primeira cabe em qualquer anúncio vazio.",
          "O problema precisa ser reconhecido pela outra pessoa com as palavras dela. Se só você acha que dói, você tem um tema, não um nicho. Nicho pequeno é melhor no começo. Todo mundo que quer ganhar dinheiro não é público. É multidão.",
          "Escreva também o que o material não faz. Não tira dívida, não escolhe ação, não garante a primeira venda na Kiwify. Limite honesto evita reembolso e evita que você prometa o que a aula 9 vai recusar.",
        ],
      },
      {
        title: "Quem é o leitor",
        paragraphs: [
          "Dê nome, idade aproximada, renda em faixa e uma restrição. A Marina, 27 anos, assistente, R$ 2.800 fictícios, mora com a mãe e tem uma parcela de loja. Esse retrato impede o texto de falar com um milionário imaginário.",
          "Onde essa pessoa já está? Grupo da família, comentário de um vídeo, fila do trabalho, igreja, faculdade. Você não precisa de audiência. Precisa de um lugar onde uma conversa seja possível sem invadir.",
          "Se você mesmo é o leitor, ótimo: escreva o que você precisava há um ano. Não escreva o que um guru acharia avançado. Iniciante compra clareza, não jargão.",
        ],
      },
      {
        title: "Validar sem gastar",
        paragraphs: [
          "Ordem de força, da mais fraca para a mais forte: curtida, comentário, conversa, pedido para ver uma amostra, uso da amostra, pagamento. O gráfico desta aula usa 1, 2, 3 e 5 só para mostrar essa escada. Não são pessoas. Não são reais.",
          "Conversa boa pergunta o que a pessoa já tentou e onde travou. Conversa ruim apresenta o produto no primeiro minuto. Você está coletando linguagem. As palavras dela viram título de capítulo depois.",
          "Não pague anúncio para validar uma frase que você ainda não disse em voz alta para ninguém. Dinheiro de teste, aqui, é zero. Tempo é o custo.",
        ],
      },
      {
        title: "Quando parar a ideia",
        paragraphs: [
          "Pare se o problema só existe em headline de outro curso. Pare se a solução depende de mentir resultado. Pare se você precisa de seguidor, estúdio ou empréstimo para dar o primeiro passo. O primeiro passo é uma frase e duas conversas.",
          "Trocar de ideia na aula 4 é barato. Trocar depois de gravar dez aulas e abrir checkout é caro. Por isso a validação vem antes da Kiwify, não depois.",
          "Uma pessoa empolgada não é mercado. Duas conversas também não são. São o mínimo para não inventar no vazio. O funil de verdade, com gente contada, aparece só na tentativa da aula 9 e no desenho da aula 19.",
        ],
      },
    ],
    chart: {
      type: "funnel",
      title: "Força do sinal, não faturamento",
      caption: "Escala ilustrativa: conversa, lista, amostra e venda não são números reais de gente.",
      labels: ["Conversas", "Lista", "Amostra", "Venda"],
      values: [1, 2, 3, 5],
    },
    reads: ["Funil não é caixa", "Like é sinal fraco", "Comece por um problema"],
    readText: [
      "A largura mostra o quanto o sinal é confiável, não quantas pessoas compraram.",
      "Publicação com curtida não valida nicho. Pergunta respondida chega mais perto.",
      "Escreva quem sofre, com o quê, e o que muda se o material funcionar.",
    ],
    mistakes: [
      "Escolher nicho porque outro curso disse que está bombando.",
      "Abrir a Kiwify antes de falar com uma pessoa real.",
      "Tratar curtida como pedido de compra.",
    ],
    practice: [
      "Liste dez problemas e risque até sobrar um.",
      "Escreva a frase do problema com o limite: o que o material não promete.",
      "Descreva o leitor em dez linhas.",
      "Envie ou faça duas conversas. Copie três frases literais que você ouviu.",
      "Decida: segue, ajusta a frase, ou troca o problema.",
    ],
    checks: [
      { q: "Like valida um nicho?", a: "Não. É o sinal mais fraco. Conversa, amostra usada e pagamento são mais fortes, nessa ordem." },
      { q: "O funil desta aula é meta de vendas?", a: "Não. Os valores 1, 2, 3 e 5 só ordenam a força do sinal." },
      { q: "Quando o produto ainda não existe?", a: "Enquanto o problema não cabe numa frase que outra pessoa reconhece." },
    ],
    task: "Entregue a frase do problema, o retrato do leitor e o registro de duas conversas, mesmo que uma tenha sido curta. Sem conversa, a aula 5 não tem o que pedir para a inteligência artificial.",
  },
  {
    id: 5,
    title: "IA para infoprodutos",
    card: "Prompts para rascunhar, nunca para publicar no automático.",
    lede: "A inteligência artificial acelera o primeiro texto. A revisão é o que torna o material seu.",
    graphic: false,
    duration: "2h30",
    objectives: [
      "Pedir um rascunho com contexto, público e limite claro.",
      "Conferir fato, tom e originalidade antes de publicar.",
      "Recusar texto que copia curso alheio ou inventa prova.",
    ],
    paragraphs: [
      "Um prompt útil diz quem é o leitor, qual problema o material cobre, o que não pode prometer e em que formato entregar. Escreva um e-book que vende todo dia produz frase pronta e vazia. Liste oito erros de orçamento de quem ganha pouco, sem prometer riqueza produz um rascunho que você consegue revisar.",
      "Gerar é a parte curta. Revisar é a parte do curso. Troque exemplo genérico pelo que você sabe explicar. Apague depoimento que não aconteceu, urgência falsa e número de aluno inventado. Se a ferramenta não cita a fonte, o número não entra no material.",
    ],
    plan: [
      { min: "15 min", text: "Releia a frase do problema da aula 4. Se não existir, pare e faça antes de abrir qualquer ferramenta." },
      { min: "20 min", text: "Escreva o prompt no papel, com leitor, limite e formato. Só depois cole na ferramenta, se for usar uma." },
      { min: "20 min", text: "Peça só um sumário de cinco capítulos. Não peça o livro inteiro." },
      { min: "40 min", text: "Revise título por título: ensina ou promete? Troque o que estiver genérico." },
      { min: "30 min", text: "Risque qualquer número, depoimento ou taxa sem fonte. Reescreva dois parágrafos com a sua voz." },
      { min: "25 min", text: "Monte a lista do que ainda precisa ser escrito por você, sem a máquina." },
    ],
    sections: [
      {
        title: "O que um prompt precisa ter",
        paragraphs: [
          "Quatro peças: quem lê, qual dor, o que está proibido de prometer, e o formato da resposta. Sem o proibido, a ferramenta preenche com riqueza rápida porque esse é o texto mais comum que ela viu.",
          "Peça pouco. Sumário, lista de objeções, roteiro de um minuto, tabela de potes. Pedido gigante volta superficial. Você vai revisar de qualquer jeito, então comece pequeno o bastante para ler em voz alta.",
          "Inclua o seu exemplo, não peça para a ferramenta inventar uma aluna brasileira média. A Marina já tem números. Use-os e marque exemplo fictício. Isso evita que o texto pareça pesquisa.",
        ],
      },
      {
        title: "Onde o tempo de verdade vai",
        paragraphs: [
          "No gráfico ilustrativo, pedir e rascunhar levam uma hora cada. Revisar leva quatro. Cortar o que não serve leva duas. Se a sua tarde só teve a parte de gerar, o material não existe ainda.",
          "Leia em voz alta. Se você não diria aquela frase para um amigo, ela ainda está com voz de anúncio. Reescreva. A ferramenta não fica ofendida.",
          "Originalidade aqui não é nunca ter lido ninguém. É não copiar a estrutura de um concorrente e trocar o nome. Se o sumário saiu igual ao de um curso famoso, apague e comece da dor que você ouviu na aula 4.",
        ],
      },
      {
        title: "Fato, taxa e depoimento",
        paragraphs: [
          "Número de inflação, taxa de plataforma, prazo de reembolso e regra de imposto mudam. A ferramenta erra com confiança. Se você não abriu a página oficial no dia, o número não entra.",
          "Depoimento que não aconteceu é mentira, mesmo com aspas bonitas. Sem aluno, não há aspas. Você pode escrever o que uma conversa da aula 4 revelou, com permissão e sem transformar opinião em resultado financeiro.",
          "Não peça para a IA imitar um especialista famoso nem colar um capítulo de livro. Além de fraco, pode ser cópia. O material precisa sobreviver se alguém perguntar de onde veio cada afirmação.",
        ],
      },
      {
        title: "Um fluxo que cabe numa tarde",
        paragraphs: [
          "Passo 1: prompt do sumário. Passo 2: você corta dois capítulos vaidosos. Passo 3: para cada capítulo que ficou, escreva você mesmo o exemplo em reais. Passo 4: peça só uma revisão de clareza, não um recomeço. Passo 5: leia no celular, porque é ali que o leitor vai estar.",
          "Guarde o prompt junto do sumário. Quando o texto sair errado, o erro muitas vezes está no pedido. Ajustar o prompt ensina mais do que gerar de novo no escuro.",
          "Se você não tem acesso a uma ferramenta hoje, faça o sumário à mão com as mesmas regras. A aula não depende de uma marca de chatbot. Depende da revisão.",
        ],
      },
    ],
    chart: {
      type: "bar",
      title: "Onde o tempo de verdade vai",
      caption: "Horas ilustrativas: gerar é rápido, revisar é o trabalho.",
      labels: ["Pedido", "Rascunho", "Revisão", "Corte"],
      series: [{ name: "Horas", data: [1, 1, 4, 2] }],
    },
    reads: ["Rascunho não é produto", "Número sem fonte sai", "A voz tem de ser sua"],
    readText: [
      "Se você não leria o texto em voz alta para um amigo, ele ainda não está pronto.",
      "Estatística, taxa e prazo oficial precisam de página que você abriu, não de memória da IA.",
      "Reescreva o trecho que soa como qualquer outro anúncio da internet.",
    ],
    mistakes: [
      "Publicar o primeiro texto que a ferramenta devolveu.",
      "Inventar depoimento para a página ficar crível.",
      "Pedir um livro inteiro e não ter tempo de ler o que veio.",
    ],
    practice: [
      "Escreva um prompt com leitor, dor, proibição e formato.",
      "Gere ou escreva um sumário de cinco capítulos.",
      "Marque cada título: ensina ou promete. Reescreva os que prometem.",
      "Risque todo número sem fonte.",
      "Reescreva o primeiro parágrafo com um exemplo seu, em reais.",
    ],
    checks: [
      { q: "O que não pode faltar no prompt?", a: "Leitor, problema, o que está proibido de prometer e o formato da resposta." },
      { q: "Por que o gráfico dá mais horas à revisão?", a: "Porque gerar é rascunho. O material só existe depois de fato, tom e originalidade serem conferidos." },
      { q: "Dá para citar uma taxa que a IA afirmou?", a: "Só se você abriu a fonte oficial no dia. Se não abriu, a taxa sai do texto." },
    ],
    task: "Entregue o prompt, o sumário revisado e o primeiro parágrafo na sua voz. Ao lado, uma lista do que você apagou e por quê. Essa lista é a prova de que a revisão aconteceu.",
  },
];
