import type { Lesson } from "./types";

export const lessonsB: Lesson[] = [
  {
    id: 6,
    title: "Produto na Kiwify",
    card: "Oferta, preço de teste e cadastro com a documentação aberta.",
    lede: "Império Financeiro não é a Kiwify. Botão, taxa e prazo mudam: a última palavra é a central de ajuda.",
    graphic: false,
    duration: "1h30",
    objectives: [
      "Descrever a oferta em uma frase sem renda garantida.",
      "Escolher um preço de teste que você consiga explicar.",
      "Separar preço de vitrine e valor depois da taxa.",
    ],
    paragraphs: [
      "Cadastrar é seguir a tela oficial, não um tutorial antigo. Nome do produto, entrega do arquivo, preço e página precisam bater com o que você realmente entrega. Se o botão não for o deste texto, pare e releia o artigo da ajuda. Não chute.",
      "Preço de teste não é o preço dos seus sonhos. No exemplo, R$ 27 de vitrine não são R$ 27 na conta. Uma taxa ilustrativa de 8,99% mais R$ 2,49 fixos leva o líquido desta conta para cerca de R$ 22 antes de saque, reembolso e imposto. Confira a taxa vigente antes de decidir.",
    ],
    plan: [
      { min: "10 min", text: "Abra a central de ajuda da Kiwify numa aba. Esta aula perde se a tela divergir." },
      { min: "15 min", text: "Escreva a oferta em uma frase e a lista do que o arquivo realmente contém." },
      { min: "20 min", text: "Escolha um preço de teste e refaça a conta da taxa com o número oficial de hoje." },
      { min: "30 min", text: "Percorra o cadastro devagar: produto, preço, entrega. Não publique no escuro." },
      { min: "15 min", text: "Anote o que você ainda não sabe e o link do artigo que vai responder. Pare ali." },
    ],
    sections: [
      {
        title: "O que você está cadastrando",
        paragraphs: [
          "Um produto digital simples é um arquivo que a pessoa baixa depois de pagar: e-book, planilha, guia. O nome na vitrine tem de ser o nome do arquivo. Bônus que você ainda não produziu não entra no cadastro.",
          "Entrega, prazo de acesso e política de reembolso precisam ser os que você aguenta cumprir. Prometer suporte eterno numa aula de uma hora cria dívida de tempo. Escreva o que você responde e em quanto tempo.",
          "Este curso é material didático independente. Não é página da Kiwify. Taxa, botão e prazo citados são exemplo. A última palavra é o artigo oficial do dia em que você cadastra.",
        ],
      },
      {
        title: "Preço de vitrine e preço líquido",
        paragraphs: [
          "Conta ilustrativa, não tabela vigente: preço R$ 27. Se a taxa fosse 8,99% mais R$ 2,49, a parte percentual seria cerca de R$ 2,43 e o total de taxa cerca de R$ 4,92. Sobram cerca de R$ 22,08 antes de saque, imposto e reembolso. Confira cada número na ajuda antes de usar.",
          "Uma unidade não paga o mês. Não multiplique por cem vendas imaginárias para se animar. A aula 10 e a aula 20 voltam nessa conta com mais linhas.",
          "Preço de teste é o que você consegue explicar sem vergonha para o leitor da aula 4. Se R$ 27 parece aleatório, escreva o porquê: cobre X horas suas de produção e ainda fica acessível para a renda que você descreveu. Se não houver porquê, o preço ainda é chute.",
        ],
      },
      {
        title: "Quando a tela não bate",
        paragraphs: [
          "Pare. Não procure um vídeo de dois anos atrás para forçar o botão. A interface muda. O hábito certo é: li o artigo, olhei a tela, se divergiu, reli o artigo.",
          "Não peça a senha de ninguém e não passe o cadastro para um desconhecido que promete configurar. A conta é sua. A responsabilidade do que está escrito na página também.",
          "Se o arquivo ainda não está pronto, o botão de venda espera. Checkout aberto com PDF vazio é o caminho mais curto para reembolso e para quebra de confiança.",
        ],
      },
    ],
    chart: {
      type: "bar",
      title: "Preço de vitrine não é líquido",
      caption: "Conta ilustrativa de um produto a R$ 27. Confira a taxa oficial.",
      labels: ["Preço", "Taxa", "Após taxa"],
      series: [{ name: "R$", data: [27, 4.92, 22.08] }],
    },
    reads: ["A barra do meio sai", "Uma venda não paga o mês", "Tela diferente, pare"],
    readText: [
      "Desenhe sempre o que a plataforma fica, não só o preço que o aluno vê.",
      "Este gráfico é uma unidade. Não multiplique por um número de vendas imaginário.",
      "Quando a ajuda oficial divergir da aula, vença a ajuda oficial.",
    ],
    mistakes: [
      "Copiar taxa deste curso como se fosse a taxa de hoje.",
      "Publicar produto sem o arquivo pronto.",
      "Chamar o líquido de lucro antes de saque, imposto e reembolso.",
    ],
    practice: [
      "Escreva a oferta em uma frase e o que não está incluído.",
      "Abra a ajuda oficial e anote a taxa percentual e a fixa de hoje.",
      "Refaça a conta do seu preço de teste. Mostre o líquido, não só a vitrine.",
      "Liste os campos do cadastro que você ainda não entende e o artigo que vai ler.",
    ],
    checks: [
      { q: "R$ 27 cobrados são R$ 27 recebidos?", a: "Não. Taxa, saque, reembolso e imposto saem antes. No exemplo ilustrativo sobram cerca de R$ 22 antes dessas outras linhas." },
      { q: "O que fazer se o botão da tela não for o da aula?", a: "Parar e reler a central de ajuda. Não chutar." },
      { q: "Este curso é a Kiwify?", a: "Não. É material didático independente." },
    ],
    task: "Deixe numa folha: frase da oferta, preço de teste, taxa copiada da ajuda com a data de hoje, e o líquido estimado. Não publique enquanto essa folha não existir.",
  },
  {
    id: 7,
    title: "Página de vendas",
    card: "Texto honesto, estrutura clara e leitura boa no celular.",
    lede: "A página explica o material. Ela não finge escassez, depoimento ou turma fechando.",
    graphic: false,
    duration: "2h30",
    objectives: [
      "Ordenar promessa, para quem é, o que tem dentro e o preço.",
      "Escrever para a tela do celular, com frase curta.",
      "Tirar qualquer prova que você não possa mostrar.",
    ],
    paragraphs: [
      "Uma página simples tem seis blocos: o problema, para quem serve, o que a pessoa recebe, como usar, o preço e as perguntas que você já ouviu. Cada bloco responde uma dúvida. Nenhum bloco existe para empurrar.",
      "Copy boa é específica. Organize um mês com sete potes é verificável. Mude de vida em sete dias não é. Se a página ficar longa no computador e ilegível no telefone, o telefone ganha: é nele que a maior parte das pessoas lê.",
    ],
    plan: [
      { min: "20 min", text: "Leia os seis blocos e escreva uma frase para cada um, no celular, não no computador." },
      { min: "30 min", text: "Expanda cada bloco para um parágrafo curto. Corte adjetivo que você não sustentaria numa conversa." },
      { min: "20 min", text: "Liste as perguntas reais da aula 4. Responda sem inventar resultado." },
      { min: "20 min", text: "Olhe o gráfico de peso. Ele organiza a página, não mede visita." },
      { min: "45 min", text: "Leia tudo em voz alta no telefone. Marque onde você tropeça. Reescreva esses trechos." },
      { min: "15 min", text: "Apague escassez falsa, depoimento inventado e qualquer número sem fonte." },
    ],
    sections: [
      {
        title: "Os seis blocos",
        paragraphs: [
          "Problema: a cena, não o slogan. Para quem: o retrato da aula 4, incluindo quem não deve comprar. Entrega: a lista real de arquivos. Uso: o que a pessoa faz na primeira sentada, em minutos, não em transformação de vida.",
          "Preço: o número inteiro, o que está incluído e como pede reembolso se você oferece. Dúvidas: as objeções que já apareceram, com resposta curta. Se ainda não houve pergunta, use as da sua própria cabeça de iniciante e marque que são antecipações.",
          "O gráfico dá peso ilustrativo: problema 5, para quem 4, entrega 5, preço 3, dúvidas 4. Não é tráfego. É um lembrete para não fazer uma página que só tem preço e promessa.",
        ],
      },
      {
        title: "Frase que aguenta conversa",
        paragraphs: [
          "Teste: você leria isso para a Marina sem baixar a voz? Se a frase precisa de música épica, está grande demais. Troque por verbo concreto: anotar, somar, separar, comparar.",
          "Provas aceitáveis: o sumário, uma página de amostra, a conta que você fez na frente da pessoa. Provas inaceitáveis: print de saldo que não é seu, aluno que não existe, vagas acabando quando o arquivo é digital e infinito.",
          "Urgência real é rara no começo. Você não tem turma fechando. Não invente. Quem compra no susto reembolsa no outro dia, e o reembolso come a conta da aula 10.",
        ],
      },
      {
        title: "Celular primeiro",
        paragraphs: [
          "Escreva com a largura de um telefone. Parágrafo de quatro linhas. Título que não quebra em seis linhas. Botão com o preço visível, não só compre agora.",
          "Leia de pé, com o brilho baixo, como quem está no ônibus. Se você precisa dar zoom, a página falhou. Se o primeiro bloco não diz o problema, a pessoa volta para o vídeo.",
          "Link da Kiwify só entra quando o cadastro da aula 6 existe de verdade. Página apontando para checkout vazio é pressa.",
        ],
      },
      {
        title: "Uma passada de honestidade",
        paragraphs: [
          "Procure estas palavras e desconfie de cada uma: garantido, automático, sem esforço, renda diária, último dia, só hoje, alunos em todo o Brasil. Se não houver fato atrás, apague.",
          "Diga o que o material exige da pessoa: sentar, abrir extrato, fazer conta. Quem procura mágica não é o seu leitor. Deixar isso escrito filtra e protege você.",
          "Guarde a versão. A aula 14 vai usar as mesmas respostas quando a objeção chegar no comentário. Página e conversa não podem se contradizer.",
        ],
      },
    ],
    chart: {
      type: "bar",
      title: "Peso de cada bloco da página",
      caption: "Importância relativa ilustrativa, não um funil de visitas.",
      labels: ["Problema", "Para quem", "Entrega", "Preço", "Dúvidas"],
      series: [{ name: "Peso", data: [5, 4, 5, 3, 4] }],
    },
    reads: ["Peso não é tráfego", "Preço aparece inteiro", "Dúvida também vende clareza"],
    readText: [
      "O gráfico só organiza a página. Ele não mede clique nem conversão.",
      "Esconder taxa, bônus falso ou prazo inventado quebra a confiança que o texto tenta criar.",
      "Responda se serve para quem ainda não investe, sem envergonhar o leitor.",
    ],
    mistakes: [
      "Escrever no computador e nunca ler no celular.",
      "Inventar escassez para um arquivo digital.",
      "Colocar depoimento de aluno que você não tem.",
    ],
    practice: [
      "Escreva os seis blocos em frases curtas no celular.",
      "Expanda cada um para um parágrafo.",
      "Risque toda promessa que você não sustentaria em voz alta.",
      "Leia a página inteira em voz alta e marque os tropeços.",
      "Reescreva os tropeços até a leitura caber numa sentada curta.",
    ],
    checks: [
      { q: "O gráfico desta aula mede visitas?", a: "Não. Ele só lembra o peso de cada bloco da página." },
      { q: "Dá para escrever últimas vagas se o arquivo é um PDF?", a: "Não. Escassez falsa não entra. O arquivo não acaba." },
      { q: "Onde a página deve ser legível primeiro?", a: "No celular. Se no telefone falhar, a página falhou." },
    ],
    task: "Entregue a página em texto, lida no celular, sem depoimento inventado e sem escassez. No topo, a frase do problema da aula 4. No fim, o preço de teste da aula 6.",
  },
  {
    id: 8,
    title: "Divulgação orgânica",
    card: "Conteúdo útil em vídeo curto, sem obrigação de aparecer.",
    lede: "Um roteiro honesto vale mais do que spam em grupo ou escassez inventada.",
    graphic: false,
    duration: "1h30",
    objectives: [
      "Planejar sete peças que ensinam algo utilizável.",
      "Gravar sem mostrar o rosto, se essa for a sua escolha.",
      "Ler comentário como dúvida, não como prova de venda.",
    ],
    paragraphs: [
      "Divulgação orgânica é presença repetida onde o seu leitor já está: vídeo curto, carrossel, resposta a uma pergunta. A peça mostra um pedaço do método — por exemplo, como separar necessidade de desejo — e só no fim aponta o material. Não comece pelo preço.",
      "Sete dias ilustrativos: um tema por dia, uma peça por dia, descanso no meio se a vida apertar. Comentário quanto custa é interesse, não é venda. Comentário vou ficar rico pede a frase difícil: não, este material não garante renda.",
    ],
    plan: [
      { min: "15 min", text: "Escolha o lugar onde o leitor da aula 4 já está. Um lugar só." },
      { min: "20 min", text: "Escreva sete temas. Cada tema é uma frase que a pessoa usa mesmo sem comprar." },
      { min: "25 min", text: "Roteirize a primeira peça em até 45 segundos: problema, passo, limite, convite leve." },
      { min: "20 min", text: "Grave ou escreva a peça sem aparecer, se preferir. Publique ou deixe pronta." },
      { min: "10 min", text: "Anote como você vai ler comentário amanhã, sem transformar view em faturamento." },
    ],
    sections: [
      {
        title: "Peça que ensina",
        paragraphs: [
          "Estrutura curta: uma dor em uma frase, um passo que cabe hoje, o que esse passo não resolve, e só então o material para quem quiser o resto. Se você tira o convite final e a peça continua útil, ela está boa.",
          "Não precisa de rosto, cenário ou tendência. Texto na tela, voz, papel filmado de cima. O leitor da aula 4 quer a conta, não a sua casa.",
          "Spam em grupo de família e comentário copiado em post alheio queimam o pouco de confiança que a página tenta construir. Um lugar, bem feito, ganha de dez lugares invadidos.",
        ],
      },
      {
        title: "O calendário de sete dias",
        paragraphs: [
          "O gráfico mostra uma peça por dia útil e zero no dia 4, de propósito. Altura 1 não é sucesso de audiência. É quantidade de peças. View não entra nesse desenho porque view não é compra.",
          "Dia sem peça pode ser folga marcada. O erro é chamar a folga de fracasso e, no dia seguinte, postar cinco vezes em desespero. Constância pequena ganha de maratona seguida de sumiço.",
          "Temas que cabem: os sete potes, saldo não é patrimônio, por que empréstimo não é receita, como ler uma taxa, o que a página não promete. Temas que não cabem: fiz R$ 10 mil essa semana, mesmo que um dia seja verdade e você não consiga mostrar a conta completa.",
        ],
      },
      {
        title: "Comentário sem autoengano",
        paragraphs: [
          "Quanto custa merece o preço e o que está incluído. Tá caro merece o líquido do leitor: para quem a página foi escrita, o preço de teste ou não cabe. Você não discute a vida da pessoa. Você esclarece a oferta.",
          "Vou ficar rico merece não. Sem anexo, sem emoji de foguete, sem entretanto que devolva a promessa. A frase difícil protege você de um reembolso e protege a pessoa de uma expectativa falsa.",
          "Não responda no automático com texto de IA sem ler. A aula 5 serve para rascunhar. A resposta pública é sua voz, curta, e igual à página.",
        ],
      },
    ],
    chart: {
      type: "bar",
      title: "Uma peça por dia útil",
      caption: "Calendário fictício. A altura é quantidade de peças, não de views.",
      labels: ["D1", "D2", "D3", "D4", "D5", "D6", "D7"],
      series: [{ name: "Peças", data: [1, 1, 1, 0, 1, 1, 1] }],
    },
    reads: ["Altura 1 não é sucesso", "O zero também é plano", "View não é compra"],
    readText: [
      "O gráfico só cobra constância. Alcance alto com mentira não entra na conta.",
      "Dia sem peça pode ser folga marcada, não fracasso.",
      "Não some visualização e chame de faturamento. São unidades diferentes.",
    ],
    mistakes: [
      "Começar a peça pelo preço e pelo link.",
      "Spam em grupo para compensar falta de conteúdo.",
      "Ler visualização como se fosse venda.",
    ],
    practice: [
      "Escreva os sete temas numa lista.",
      "Roteirize a peça 1 em menos de 45 segundos.",
      "Grave ou diagram sem mostrar o rosto.",
      "Escreva a resposta padrão para vou ficar rico, com a palavra não.",
    ],
    checks: [
      { q: "O gráfico conta views?", a: "Não. Conta peças publicadas num calendário fictício." },
      { q: "Precisa aparecer?", a: "Não. A peça pode ser texto, voz ou papel filmado." },
      { q: "Como responder vou ficar rico?", a: "Dizendo que o material não garante renda. Sem devolver a promessa no final da frase." },
    ],
    task: "Entregue os sete temas, o roteiro da primeira peça e a resposta escrita para a objeção de ficar rico. Publique só se a peça continuar útil sem o link.",
  },
  {
    id: 9,
    title: "A primeira venda",
    card: "Sete dias de tentativa. Sem garantia de resultado.",
    lede: "A aula entrega um plano de execução. Ela não assina contrato com o seu faturamento.",
    graphic: false,
    duration: "2h30",
    objectives: [
      "Executar uma sequência curta sem anúncio pago.",
      "Responder objeção sem inventar resultado.",
      "Encerrar a semana com o que aconteceu, não com o que você esperava.",
    ],
    paragraphs: [
      "Um plano de sete dias pode ser: revisar a página, publicar três peças úteis, falar com as pessoas da aula 4, responder dúvida em público e conferir se o checkout abre no celular. Isso é trabalho. Não é método secreto.",
      "Se ninguém comprar, o plano não falhou como aula: ele produziu um fato. Preço alto, página confusa, problema fraco ou público errado são hipóteses. Empréstimo para acelerar não é o próximo passo.",
    ],
    plan: [
      { min: "20 min", text: "Escreva os sete dias com uma ação e um horário que cabe na sua rotina real." },
      { min: "20 min", text: "Revise a página da aula 7 no celular e o checkout, se ele já existir." },
      { min: "30 min", text: "Prepare três peças a partir dos temas da aula 8. Não invente tema novo." },
      { min: "20 min", text: "Liste as pessoas da aula 4 e a mensagem, sem áudio enorme e sem promessa." },
      { min: "20 min", text: "Leia o funil fictício. 40, 12, 4 e 1 não são a sua meta." },
      { min: "40 min", text: "Execute o dia 1 agora, se o horário for este. Se não for, deixe o alarme e não encha a semana de tarefa extra para compensar." },
    ],
    sections: [
      {
        title: "Um dia, uma ação",
        paragraphs: [
          "Dia 1: ler a página em voz alta e cortar uma frase falsa. Dia 2: publicar a primeira peça. Dia 3: conversar com uma pessoa da aula 4. Dia 4: folga marcada ou revisão do checkout no celular. Dia 5: segunda peça. Dia 6: responder o que chegou, mesmo que seja silêncio anotado. Dia 7: terceira peça e o fechamento da semana no papel.",
          "Horário que não cabe não é plano. É desejo. Se você trabalha o dia inteiro, quarenta minutos depois do jantar contam mais do que um sábado imaginário de oito horas.",
          "Não acrescente anúncio pago no meio da semana porque o silêncio incomodou. O teste desta aula é orgânico de propósito. Dinheiro de casa não financia o susto.",
        ],
      },
      {
        title: "O funil é exemplo, não contrato",
        paragraphs: [
          "No desenho fictício, 40 conversas viram 12 respostas, 4 amostras e 1 venda. Serve para você ler um funil estreito. Não serve para você escrever meta: tenho que fazer 40 conversas e fechar 1. A sua semana pode terminar em zero. Zero é um resultado honesto.",
          "Não some as faixas. Quem está na venda já passou pelas de cima. Somar 40+12+4+1 e chamar de 57 pessoas é erro de leitura, e a aula 19 aprofunda isso.",
          "Uma venda, se vier, não vira prova de método nem print de renda. Anote o que a pessoa perguntou antes de pagar. Isso vale mais do que o valor.",
        ],
      },
      {
        title: "Mensagem sem teatro",
        paragraphs: [
          "Para quem já conversou com você: lembre o problema que a própria pessoa citou, diga o que o arquivo contém e o preço, e deixe a porta aberta para não comprar. Sem áudio de dez minutos. Sem vou te ajudar a mudar de vida.",
          "Se a pessoa sumir, uma segunda mensagem basta. A terceira vira pressão. Silêncio é resposta.",
          "Em público, responda a dúvida de um jeito que quem não vai comprar também aprenda alguma coisa. O comentário é uma peça pequena da aula 8.",
        ],
      },
      {
        title: "O oitavo dia",
        paragraphs: [
          "Escreva o que foi feito, o que travou e o número real: peças, conversas, respostas, vendas. Não complete com achismo. Se não contou, o número é desconhecido, não é zero nem é dez.",
          "Hipóteses permitidas: a frase do problema não doeu, o preço não coube, a página não foi lida, você não falou com ninguém. Hipótese proibida: eu não nasci para isso. Isso não é dado.",
          "O próximo passo, se a semana foi oca, é ajustar uma coisa só. Problema, ou preço, ou página. Não os três ao mesmo tempo, senão você não sabe o que mudou. A aula 15 organiza os quatorze dias seguintes.",
        ],
      },
    ],
    chart: {
      type: "funnel",
      title: "Uma semana fictícia",
      caption: "40 conversas, 12 respostas, 4 amostras, 1 venda. Números inventados.",
      labels: ["Conversas", "Respostas", "Amostras", "Venda"],
      values: [40, 12, 4, 1],
    },
    reads: ["Uma venda não é meta nacional", "O fundo pode ser zero", "Não complete com anúncio no crédito"],
    readText: [
      "O exemplo existe para você ler um funil, não para copiar a meta de uma venda certa.",
      "Zero no último degrau é um resultado possível e honesto.",
      "Dinheiro de aluguel, comida ou dívida não financia teste de anúncio.",
    ],
    mistakes: [
      "Transformar o funil fictício em meta obrigatória.",
      "Mandar cinco mensagens para a mesma pessoa.",
      "Pegar empréstimo porque a semana ficou em zero.",
    ],
    practice: [
      "Escreva a grade dos sete dias com horário real.",
      "Deixe três peças prontas ou roteirizadas.",
      "Escreva a mensagem para uma pessoa da aula 4, com o não obrigatório possível.",
      "Abra o checkout no celular e anote se algo quebrou.",
      "Prepare a folha do oitavo dia, com as colunas vazias esperando número real.",
    ],
    checks: [
      { q: "A aula garante uma venda em sete dias?", a: "Não. Ela garante um plano de tentativa. O fundo do funil pode ser zero." },
      { q: "Dá para somar as faixas do funil?", a: "Não. Quem comprou já estava nas faixas de cima. Somar conta gente duas vezes." },
      { q: "Qual é o próximo passo se ninguém comprar?", a: "Anotar o fato e ajustar uma variável só. Não financiar anúncio com dívida." },
    ],
    task: "Saia desta aula com a grade de sete dias preenchida e o dia 1 feito ou agendado de verdade. No oitavo dia, a folha de números reais é a entrega. Sem maquiagem.",
  },
  {
    id: 10,
    title: "Gestão e lucro real",
    card: "Taxa, reembolso, saque e o que sobra de verdade.",
    lede: "Faturamento é o que passou no checkout. Lucro é o que resta depois das contas.",
    graphic: false,
    duration: "1h30",
    objectives: [
      "Tirar taxa, reembolso, anúncio e saque do bruto.",
      "Separar o dinheiro do produto do dinheiro da casa.",
      "Decidir o próximo mês sem chamar faturamento de lucro.",
    ],
    paragraphs: [
      "Oito vendas a R$ 27 dão R$ 216 de bruto neste exemplo. Taxas ilustrativas de R$ 34 e um saque de R$ 4 saem antes da sobra. A barra que importa é a última: R$ 178, e mesmo ela ainda não é salário — imposto, anúncio e reembolso não entraram.",
      "Caixa do produto não paga mercado no automático. Separe um percentual para um reinvestimento pequeno e outro para a sua reserva pessoal. Imposto depende do seu caso: isso é conversa com contador, não com este curso.",
    ],
    plan: [
      { min: "15 min", text: "Copie as quatro barras e refaça 8 × 27 no papel." },
      { min: "20 min", text: "Monte a sua linha mesmo com zero vendas. Zero é um painel válido." },
      { min: "20 min", text: "Separe no papel o que seria caixa do produto e o que seria conta de casa." },
      { min: "20 min", text: "Escreva o que você não vai chamar de lucro: bruto, view, parcela a receber." },
      { min: "15 min", text: "Anote a pergunta que você faria a um contador antes de misturar esse dinheiro com a renda." },
    ],
    sections: [
      {
        title: "A conta da simulação",
        paragraphs: [
          "8 × 27 = 216. Esse é o bruto, a barra vaidosa. Taxas ilustrativas de R$ 34 e um saque de R$ 4 levam a uma sobra de R$ 178 nessa simulação estreita. Se entrar reembolso de uma venda, o bruto que permanece cai e a taxa daquela unidade pode ou não voltar: confira a regra do dia, não esta aula.",
          "Anúncio, mesmo pequeno, sai dessa sobra. Ferramenta paga também. Se você não lançar, vai lembrar só dos R$ 216 e achar que o mês deu certo.",
          "Antecipar recebimento pode ter custo próprio. Não está nas quatro barras. Se você usar, vira uma quinta linha, não um detalhe.",
        ],
      },
      {
        title: "Dois caixas",
        paragraphs: [
          "O dinheiro do produto não é o dinheiro do aluguel até você decidir uma transferência com número. Uma conta separada, ou pelo menos uma nota separada, evita gastar a sobra duas vezes.",
          "Reinvestimento tem teto. Página, uma ferramenta, tempo. Reinvestir tudo e viver no aperto não é gestão. Reserve pessoal continua valendo, a da aula 2, mesmo depois da primeira venda.",
          "Print de faturamento sem a coluna das taxas engana quem lê e quem posta. Se você for mostrar número, mostre bruto e sobra, com a palavra simulação ou o mês real escrito, e a data.",
        ],
      },
      {
        title: "O que esta aula não calcula",
        paragraphs: [
          "Imposto, nota e enquadramento mudam com o seu caso e com a regra do ano. Não copie porcentagem de vídeo. Leve a sua linha de lucro para quem é habilitado quando o valor deixar de ser exercício.",
          "Esta aula também não diz para você largar o emprego. Uma sobra de R$ 178 fictícios não sustenta ninguém. Trate como treino de leitura até os seus números reais existirem por vários meses.",
          "Se as vendas foram zero, o painel é bruto zero, taxa zero, sobra zero. Ainda assim escreva. O hábito começa antes do primeiro real.",
        ],
      },
    ],
    chart: {
      type: "bar",
      title: "Do bruto até a sobra",
      caption: "Simulação fictícia. Não é extrato da Kiwify.",
      labels: ["Bruto", "Taxas", "Saque", "Sobra"],
      series: [{ name: "R$", data: [216, 34, 4, 178] }],
    },
    reads: ["Bruto é a barra vaidosa", "Sobra é a barra útil", "Reinvestimento tem teto"],
    readText: [
      "Print de faturamento sem a coluna das taxas engana quem lê e quem posta.",
      "Some de novo no papel: bruto − taxas − saque − anúncio − reembolso.",
      "Reinvestir tudo e viver no aperto não é gestão. É pressa com outro nome.",
    ],
    mistakes: [
      "Postar o bruto e chamar de lucro.",
      "Misturar a primeira sobra com o mercado da casa no mesmo dia.",
      "Ignorar reembolso porque o print já foi feito.",
    ],
    practice: [
      "Refaça 8 × 27 e a subtração das taxas do exemplo.",
      "Monte a sua linha com os seus números, mesmo zeros.",
      "Escreva uma regra de dois caixas em uma frase.",
      "Anote o que você perguntaria a um contador.",
    ],
    checks: [
      { q: "Quanto é o bruto de oito vendas a R$ 27?", a: "R$ 216. Isso não é a sobra." },
      { q: "A sobra de R$ 178 já é salário?", a: "Não. Imposto, anúncio e reembolso ainda não entraram nessa simulação." },
      { q: "Dá para usar o dinheiro do produto como se fosse a conta de casa?", a: "Só depois de uma transferência decidida. Antes disso, são caixas diferentes." },
    ],
    task: "Entregue o painel de quatro linhas com os seus números e a frase do que você não vai chamar de lucro. Se ainda não vendeu, entregue a linha de zeros sem vergonha.",
  },
  {
    id: 11,
    title: "Dívida sem empilhar",
    card: "Nomear parcela, juros e o que não fazer para tapar o mês.",
    lede: "Antes de vender qualquer coisa, você precisa saber qual dívida já está comendo o salário.",
    graphic: false,
    duration: "2h30",
    objectives: [
      "Listar cada dívida com parcela, prazo e juros se você souber.",
      "Separar dívida barata de dívida que cresce sozinha.",
      "Negociar sem tomar crédito novo para tapar o antigo.",
    ],
    paragraphs: [
      "A parcela de R$ 180 da Marina é despesa deste mês e, ao mesmo tempo, um pedaço de uma dívida maior que continua depois do pagamento. Pagar a parcela não significa que a dívida acabou. Significa que o mês honrou o combinado.",
      "Este curso não negocia por você e não indica agiota, aplicativo de crédito fácil nem empréstimo para investir em anúncio. Se a dívida já tomou a renda, o mapa desta aula é o começo de uma conversa com o credor e, se preciso, com alguém habilitado. Não é uma sentença.",
    ],
    plan: [
      { min: "20 min", text: "Liste toda obrigação: loja, cartão, cheque especial, empréstimo, dinheiro emprestado de pessoa." },
      { min: "25 min", text: "Para cada linha, escreva parcela, quantas faltam se souber, e a taxa se estiver no contrato. Onde não souber, coloque interrogação." },
      { min: "20 min", text: "Separe as que crescem quando você atrasa das que são só combinado sem juros novos." },
      { min: "25 min", text: "Leia o roteiro de negociação e adapte uma frase para o seu caso, sem ameaça e sem mentira." },
      { min: "40 min", text: "Monte a ordem de ataque: primeiro a que mais cresce, não a que mais envergonha." },
      { min: "20 min", text: "Escreva o que você não vai fazer este mês: crédito novo, rotativo para pagar mínimo e fingir que sumiu, anúncio no cartão." },
    ],
    sections: [
      {
        title: "Dar nome a cada conta",
        paragraphs: [
          "Dívida sem nome vira um peso único e impossível. No papel ela vira linhas. Linha tem dono, parcela e data. A Marina, no exemplo, tem uma parcela de loja de R$ 180. Isso não é gasto à toa. É compromisso. Cortar sem negociar gera juros e nome sujo.",
          "Cartão mereçe duas linhas se for o caso: a fatura do mês e o rotativo, se existir. Rotativo não é a mesma coisa que uma compra parcelada. O rotativo cresce rápido. A parcela da loja, em geral, já tem tamanho combinado.",
          "Dinheiro que você pegou com familiar também entra. Sem juros, às vezes, mas com data e com relação. Esconder do papel não faz a dívida menor. Faz o orçamento mentir.",
        ],
      },
      {
        title: "Qual dívida atacar primeiro",
        paragraphs: [
          "Duas lógicas honestas. Uma olha a taxa: a que cresce mais rápido recebe o extra, quando existe extra. A outra olha a menor saldo: quitar uma conta pequena libera uma parcela e dá fôlego. As duas podem ser certas. O que não pode é atacar no chute enquanto o rotativo corre.",
          "Exemplo fictício, não é a sua vida: rotativo imaginário de R$ 600 crescendo todo mês, e a parcela da loja de R$ 180 já contratada. O extra, se aparecer, vai primeiro para estancar o que cresce. A parcela da loja continua sendo paga no dia, para não virar uma segunda bola de neve.",
          "Não existe extra se o saldo do mês é zero. Aí a conversa não é investimento nem produto. É reduzir desejo, renegociar prazo ou aumentar renda devagar. As três são legítimas. A quarta, crédito novo para tapar, só empurra.",
        ],
      },
      {
        title: "Como falar com o credor",
        paragraphs: [
          "Frase útil: eu consigo pagar R$ X por mês, não consigo o valor cheio, quero um plano escrito. Frase inútil: semana que vem eu resolvo tudo, sem número. Peça o acordo por escrito. Sem escrito, a conversa não aconteceu.",
          "Não aceite a primeira oferta no susto se você não entendeu a taxa do acordo. Pergunte o valor total que será pago, não só a parcela pequena. Parcela pequena com prazo eterno pode custar mais.",
          "Desconfie de intermediário que pede pagamento adiantado para limpar o nome. E desconfie de qualquer pessoa que ofereça dinheiro hoje com juros por fora do banco. Agiota não é estratégia desta aula.",
        ],
      },
      {
        title: "O que fica proibido enquanto a casa aperta",
        paragraphs: [
          "Não compre anúncio no cartão para vender o infoproduto. Não parcele um curso de promessa. Não use a reserva de remédio para parecer empreendedor. O produto digital espera. O juros não.",
          "Se você já tem o arquivo da aula 6 pronto, pode continuar a divulgação orgânica da aula 8, porque ela custa tempo, não rotativo. O limite é não misturar a pressa da venda com a dívida que já dói.",
          "Anote uma revisão mensal de quinze minutos: o que baixou, o que atrasou, se o acordo foi cumprido. Dívida sem revisão volta a ser neblina.",
        ],
      },
    ],
    chart: {
      type: "bar",
      title: "Duas dívidas fictícias",
      caption: "Parcela da loja 180 por mês. Rotativo ilustrativo 600, que cresce se ficar parado. Não é a sua conta.",
      labels: ["Parcela", "Rotativo", "Extra"],
      series: [{ name: "R$", data: [180, 600, 80] }],
    },
    reads: ["Parcela não é a dívida inteira", "O que cresce vem primeiro", "Crédito novo não apaga"],
    readText: [
      "Pagar R$ 180 honra o mês. O saldo devedor pode continuar.",
      "Se só houver um extra pequeno, ele estanca o juros mais rápido, não o constrangimento maior.",
      "Empréstimo para pagar empréstimo só muda o nome do credor.",
    ],
    mistakes: [
      "Juntar todas as dívidas num número só e desistir.",
      "Pagar só o mínimo do cartão e achar que está quitando.",
      "Tomar crédito novo para anunciar o produto.",
    ],
    practice: [
      "Liste cada dívida numa linha, com parcela e interrogação onde faltar a taxa.",
      "Marque qual linha cresce sozinha quando atrasa.",
      "Escolha a ordem de ataque e escreva o porquê em uma frase.",
      "Redija a frase de negociação com um número que cabe no seu saldo.",
      "Escreva a proibição do mês: o que você não vai financiar no cartão.",
    ],
    checks: [
      { q: "Pagar a parcela quita a dívida?", a: "Não necessariamente. Quita o compromisso daquele mês. O saldo devedor pode continuar." },
      { q: "Por que o rotativo não é igual à parcela da loja?", a: "Porque o rotativo costuma crescer forte quando fica em aberto. A parcela da loja, em geral, já tem tamanho combinado." },
      { q: "Dá para anunciar o produto no cartão enquanto o rotativo corre?", a: "Não nesta aula. Anúncio no crédito, com dívida cara aberta, está fora do plano." },
    ],
    task: "Entregue a lista de dívidas, a ordem de ataque e a frase de negociação. Se a situação for maior do que um papel — negativação, pensão, doença — procure orientação habilitada e use a lista só como mapa.",
  },
  {
    id: 12,
    title: "Reserva que cabe",
    card: "Um alvo pequeno, separado da vontade de gastar.",
    lede: "A reserva começa no tamanho de uma conta, não no tamanho de um sonho de seis meses.",
    graphic: false,
    duration: "1h30",
    objectives: [
      "Definir a reserva como dinheiro de imprevisto, não de desejo.",
      "Escolher um primeiro alvo que cabe no saldo real.",
      "Decidir onde esse dinheiro fica visível e sem mistura.",
    ],
    paragraphs: [
      "A aula 2 pediu para a reserva vir antes do lazer. Esta aula dá o alvo. Se o saldo da Marina é R$ 340 e ela decide guardar R$ 200, o primeiro alvo fictício pode ser uma conta de luz, não um colchão de seis meses. Seis meses de despesa essencial é bússola de longo prazo, não a tarefa de quem ainda não separou o primeiro real.",
      "Onde guardar, neste começo, importa menos do que não misturar. Uma conta separada, um cofrinho com nome, uma caixinha com regra de só sair para imprevisto escrito. Este curso não indica banco nem produto. Indica a separação.",
    ],
    plan: [
      { min: "10 min", text: "Releia o saldo da aula 1. Se não houver saldo, o alvo da reserva pode ser zero neste mês, dito com clareza." },
      { min: "15 min", text: "Escolha um imprevisto concreto: luz, remédio, conserto pequeno, transporte de emergência." },
      { min: "20 min", text: "Defina o valor do alvo e em quantos meses o saldo real chegaria lá, sem aumentar a renda no chute." },
      { min: "20 min", text: "Escreva a regra de saque: o que autoriza tirar e o que não autoriza." },
      { min: "25 min", text: "Olhe a linha do gráfico e redesenhe com os seus aportes, mesmo que sejam menores que os da Marina." },
    ],
    sections: [
      {
        title: "Alvo pequeno de propósito",
        paragraphs: [
          "Meta de R$ 10 mil para quem fecha o mês em R$ 40 vira ficção e depois vira culpa. Meta de uma conta de luz, ou de R$ 150, cabe numa frase e numa data. Quando essa acabar, você escolhe a próxima. A reserva cresce por alvos cumpridos, não por número de capa de revista.",
          "Calcule sem magia. Se sobram R$ 50 e o alvo é R$ 200, são quatro meses, se nada mudar. Escreva os quatro meses. Se no segundo mês a sobra cair, a data anda. Andar a data não é quebrar a reserva.",
          "Não use a reserva para entrada de celular, festa ou anúncio. Isso é outro pote, com outro nome. Se você misturar, no dia do conserto o pote está vazio e você chama a reserva de mentira. A mentira foi o saque.",
        ],
      },
      {
        title: "Regra de saída",
        paragraphs: [
          "Escreva três exemplos do que autoriza sair: remédio inesperado, conserto que impede o trabalho, conta essencial que estourou por tarifa que você não viu. Escreva três que não autorizam: promoção, presente atrasado, impulso de anúncio.",
          "Quando sair, anote o motivo na mesma folha da reserva. A aula 17 vai pedir essa história para a linha não virar decoração. Saque sem motivo escrito volta a ser gasto.",
          "Reponha no mês seguinte se o saldo permitir, com um valor menor se precisar. Reposição também é plano, não castigo.",
        ],
      },
      {
        title: "Separar sem produto mirabolante",
        paragraphs: [
          "O lugar bom neste estágio é aquele que você não vê toda hora no aplicativo do mercado e que não rende conversa de guru. Pode ser simples e com rendimento baixo. O custo de deixar simples é pequeno perto do custo de colocar a reserva num lugar que você não entende.",
          "Não mova a reserva para uma aplicação com prazo travado se você pode precisar dela no mês que vem. Reserva que não sai na hora do imprevisto não é reserva. É outra meta.",
          "Se alguém oferecer rendimento alto com liquidez imediata e sem risco, volte na aula 3. Os sinais de golpe não mudaram porque agora o dinheiro tem o nome bonito de reserva.",
        ],
      },
    ],
    chart: {
      type: "line",
      title: "Quatro aportes até uma conta",
      caption: "Alvo fictício de R$ 200, com aportes de 50. A sua curva pode ser menor.",
      labels: ["M1", "M2", "M3", "M4"],
      series: [{ name: "Reserva", data: [50, 100, 150, 200] }],
    },
    reads: ["Alvo cabe no saldo", "Saque tem motivo", "Travada demais não serve"],
    readText: [
      "Se o alvo exige uma renda que você não tem, ele é fantasia.",
      "Sem motivo escrito, a saída vira gasto com outro nome.",
      "Reserva precisa poder sair no imprevisto. Prazo longo é outra meta.",
    ],
    mistakes: [
      "Copiar a meta de seis meses de despesa no primeiro mês.",
      "Gastar a reserva numa promoção e repor nunca.",
      "Colocar o dinheiro num lugar que você não consegue explicar.",
    ],
    practice: [
      "Escreva o alvo em reais e o imprevisto que ele cobre.",
      "Divida pelo que você consegue guardar e anote a data possível.",
      "Liste três saques permitidos e três proibidos.",
      "Escolha o lugar da reserva e a regra de não misturar com o lazer.",
    ],
    checks: [
      { q: "Seis meses de despesa é a tarefa desta aula?", a: "Não. É uma bússola distante. A tarefa é um alvo do tamanho de uma conta, se o saldo permitir." },
      { q: "Dá para usar a reserva na entrada de um celular?", a: "Não. Isso é desejo. A reserva sai para imprevisto escrito na regra." },
      { q: "Reserva travada por um ano serve para emergência do mês que vem?", a: "Não. Se não sai na hora, não é reserva de imprevisto." },
    ],
    task: "Entregue o alvo, a data possível, a regra de saque e o lugar onde o dinheiro vai ficar separado. Se o alvo deste mês for zero, entregue isso escrito e a data em que você vai reavaliar.",
  },
];
