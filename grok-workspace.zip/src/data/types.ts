export type Series = { name: string; data: number[] };

export type ChartSpec =
  | { type: "bar"; title: string; caption: string; labels: string[]; series: Series[] }
  | { type: "line"; title: string; caption: string; labels: string[]; series: Series[] }
  | { type: "donut"; title: string; caption: string; labels: string[]; values: number[] }
  | { type: "funnel"; title: string; caption: string; labels: string[]; values: number[] };

export type Lesson = {
  id: number;
  title: string;
  card: string;
  lede: string;
  graphic: boolean;
  duration: "1h30" | "2h30";
  objectives: [string, string, string];
  paragraphs: [string, string];
  sections: { title: string; paragraphs: string[] }[];
  plan: { min: string; text: string }[];
  chart: ChartSpec;
  reads: [string, string, string];
  readText: [string, string, string];
  mistakes: [string, string, string];
  practice: string[];
  checks: { q: string; a: string }[];
  task: string;
};
