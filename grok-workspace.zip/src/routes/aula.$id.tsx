import { createFileRoute, Link } from "@tanstack/react-router";
import { ChartView, legendItems } from "@/components/charts";
import { getLesson, lessons } from "@/data/lessons";

export const Route = createFileRoute("/aula/$id")({
  loader: ({ params }) => {
    const lesson = getLesson(params.id);
    if (!lesson) throw new Error("Aula não encontrada");
    return lesson;
  },
  head: ({ loaderData }) => ({
    meta: loaderData
      ? [{ title: `Aula ${String(loaderData.id).padStart(2, "0")} · ${loaderData.title}` }]
      : [{ title: "Aula · Império Financeiro" }],
  }),
  component: LessonPage,
  errorComponent: LessonMissing,
});

function LessonMissing() {
  return (
    <main className="lesson">
      <h1>Aula não encontrada</h1>
      <p className="lede">Essa página não faz parte das 15 aulas.</p>
      <Link to="/" hash="aulas" className="btn">
        VOLTAR AO CURSO
      </Link>
    </main>
  );
}

function LessonPage() {
  const lesson = Route.useLoaderData();
  const prev = lessons.find((item) => item.id === lesson.id - 1);
  const next = lessons.find((item) => item.id === lesson.id + 1);
  const legend = legendItems(lesson.chart);

  return (
    <main className="lesson">
      <header className="lesson-hero">
        <p className="kicker">
          <i />
          Aula {String(lesson.id).padStart(2, "0")} de 15
          {lesson.graphic ? " · aula de gráfico" : ""} · cerca de 2 horas
        </p>
        <h1>{lesson.title}</h1>
        <p className="lede">{lesson.lede}</p>
      </header>

      <div className="objs">
        {lesson.objectives.map((goal, index) => (
          <article key={goal} className="obj">
            <span>0{index + 1}</span>
            <p>{goal}</p>
          </article>
        ))}
      </div>

      <article className="prose-card">
        <h2>Nesta aula</h2>
        <p>{lesson.paragraphs[0]}</p>
        <p>{lesson.paragraphs[1]}</p>
      </article>

      <figure className="chart-block">
        <h2>{lesson.chart.title}</h2>
        <p className="caption">{lesson.chart.caption}</p>
        <div className="chart-draw">
          <ChartView chart={lesson.chart} />
        </div>
        <figcaption className="legend">
          {legend.map((item) => (
            <span key={item.label}>
              <i className="swatch" style={{ background: item.color }} />
              {item.label}
            </span>
          ))}
        </figcaption>
      </figure>

      <div className="reads">
        {lesson.reads.map((title, index) => (
          <article key={title} className="read">
            <strong>{title}</strong>
            <p>{lesson.readText[index]}</p>
          </article>
        ))}
      </div>

      <aside className="task">
        <h2>Tarefa</h2>
        <p>{lesson.task}</p>
      </aside>

      <nav className="pager" aria-label="Aulas vizinhas">
        {prev ? (
          <Link to="/aula/$id" params={{ id: String(prev.id) }} className="btn ghost">
            Aula {String(prev.id).padStart(2, "0")}
          </Link>
        ) : (
          <span className="empty">Início do curso</span>
        )}
        {next ? (
          <Link to="/aula/$id" params={{ id: String(next.id) }} className="btn">
            Aula {String(next.id).padStart(2, "0")}
          </Link>
        ) : (
          <Link to="/" hash="aulas" className="btn">
            Ver todas
          </Link>
        )}
      </nav>
    </main>
  );
}
