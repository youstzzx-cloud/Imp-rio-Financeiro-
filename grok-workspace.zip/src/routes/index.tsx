import { createFileRoute, Link } from "@tanstack/react-router";
import { useState } from "react";
import {
  BadgeCheck,
  BarChart3,
  Bot,
  FileText,
  Filter,
  Flag,
  LayoutList,
  Lightbulb,
  LineChart,
  PieChart,
  Scale,
  Share2,
  Store,
  TrendingUp,
  Wallet,
} from "lucide-react";
import { lessons } from "@/data/lessons";

const ICONS = [Wallet, LayoutList, TrendingUp, Lightbulb, Bot, Store, FileText, Share2, Flag, BadgeCheck, BarChart3, LineChart, PieChart, Filter, Scale];

export const Route = createFileRoute("/")({
  component: Home,
});

function Home() {
  const [photo, setPhoto] = useState(true);
  return (
    <main>
      <section className="hero">
        <div className="glow g1" />
        <div className="glow g2" />
        <div className="hero-content">
          <div className="hero-text">
            <h1>
              Construa seu <span className="green">Império Financeiro</span> com IA
            </h1>
            <p>
              Domine suas finanças pessoais, crie infoprodutos com inteligência artificial e prepare sua
              primeira venda na Kiwify — com aulas escritas e cinco aulas novas só de gráficos.
            </p>
            <div className="hero-actions">
              <Link to="/" hash="aulas" className="btn">
                EXPLORAR AS AULAS
              </Link>
              <Link to="/aula/$id" params={{ id: "1" }} className="btn ghost">
                COMEÇAR PELA AULA 1
              </Link>
            </div>
          </div>
          <div className="hero-image">
            {photo ? (
              <img
                src="https://images.unsplash.com/photo-1559526324-4b87b5e36e44?q=80&w=1200&auto=format&fit=crop"
                alt="Mesa de trabalho com caderno e planejamento financeiro"
                onError={() => setPhoto(false)}
              />
            ) : (
              <div className="hero-fallback" aria-hidden="true">
                <svg viewBox="0 0 640 480" width="100%" height="100%">
                  <rect x="70" y="80" width="500" height="320" rx="28" fill="white" />
                  <rect x="100" y="120" width="180" height="18" rx="9" fill="var(--color-brand)" />
                  <rect x="100" y="160" width="120" height="12" rx="6" fill="var(--color-brand-soft)" />
                  <rect x="100" y="210" width="70" height="140" rx="12" fill="var(--color-brand)" />
                  <rect x="186" y="250" width="70" height="100" rx="12" fill="var(--color-brand-dark)" />
                  <rect x="272" y="300" width="70" height="50" rx="12" fill="var(--color-brand-light)" />
                  <rect x="380" y="200" width="150" height="150" rx="75" fill="none" stroke="var(--color-brand)" strokeWidth="28" />
                </svg>
              </div>
            )}
            <div className="floating f1">Gestão inteligente</div>
            <div className="floating f2">Rota para a Kiwify</div>
          </div>
        </div>
      </section>

      <section className="section" id="aulas">
        <div className="section-title">
          <h2>Conteúdo programático completo</h2>
          <p>15 aulas planejadas para 30 horas de aprendizado prático. As cinco últimas são aulas de gráficos.</p>
        </div>
        <div className="cards">
          {lessons.map((lesson, index) => {
            const Icon = ICONS[index] ?? BarChart3;
            return (
              <Link
                key={lesson.id}
                to="/aula/$id"
                params={{ id: String(lesson.id) }}
                className="card"
              >
                <div className="card-top">
                  <span className="card-icon" aria-hidden="true">
                    <Icon size={22} />
                  </span>
                  {lesson.graphic ? <span className="tag-grafico">Gráfico</span> : <span className="card-kicker">Aula {String(lesson.id).padStart(2, "0")}</span>}
                </div>
                <h3>
                  {String(lesson.id).padStart(2, "0")} · {lesson.title}
                </h3>
                <p>{lesson.card}</p>
              </Link>
            );
          })}
        </div>
      </section>
    </main>
  );
}
