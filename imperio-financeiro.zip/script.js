(function () {
  "use strict";

  var KEY = "imperio-financeiro-v1";

  function load() {
    try {
      var data = JSON.parse(localStorage.getItem(KEY) || "");
      if (!data || typeof data !== "object") throw new Error("empty");
      data.done = data.done || {};
      data.checks = data.checks || {};
      data.budget = data.budget || null;
      return data;
    } catch (e) {
      return { done: {}, checks: {}, budget: null };
    }
  }

  function save(data) {
    try {
      localStorage.setItem(KEY, JSON.stringify(data));
      return true;
    } catch (e) {
      return false;
    }
  }

  function money(n) {
    var v = Number(n);
    if (!isFinite(v)) v = 0;
    return v.toLocaleString("pt-BR", { style: "currency", currency: "BRL" });
  }

  function num(value) {
    if (typeof value === "number") return isFinite(value) ? value : 0;
    var s = String(value == null ? "" : value).trim();
    if (!s) return 0;
    if (s.indexOf(",") !== -1) s = s.replace(/\./g, "").replace(",", ".");
    var n = parseFloat(s);
    return isFinite(n) ? n : 0;
  }

  function bootLoader() {
    var loader = document.getElementById("loader");
    var bar = document.getElementById("loaderBar");
    var percent = document.getElementById("loaderPercent");
    if (!loader) return;
    var reduce = window.matchMedia("(prefers-reduced-motion: reduce)").matches;
    var start = performance.now();
    var duration = reduce ? 0 : 620;
    function frame(now) {
      var p = duration === 0 ? 100 : Math.min(100, ((now - start) / duration) * 100);
      if (bar) bar.style.width = p + "%";
      if (percent) percent.textContent = Math.round(p) + "%";
      if (p < 100) requestAnimationFrame(frame);
      else setTimeout(function () { loader.classList.add("hide"); }, reduce ? 0 : 180);
    }
    requestAnimationFrame(frame);
    setTimeout(function () { loader.classList.add("hide"); }, 2200);
  }

  function bootMenu() {
    var btn = document.querySelector(".menu-btn");
    var menu = document.getElementById("menu");
    if (!btn || !menu) return;
    btn.addEventListener("click", function () {
      var open = menu.classList.toggle("open");
      btn.setAttribute("aria-expanded", open ? "true" : "false");
    });
    menu.querySelectorAll("a").forEach(function (a) {
      a.addEventListener("click", function () {
        menu.classList.remove("open");
        btn.setAttribute("aria-expanded", "false");
      });
    });
  }

  function renderProgress() {
    var data = load();
    var total = 10;
    var count = 0;
    for (var i = 1; i <= total; i++) if (data.done[String(i)]) count++;
    var bar = document.getElementById("courseBar");
    var label = document.getElementById("courseCount");
    if (bar) bar.style.width = (count / total) * 100 + "%";
    if (label) label.textContent = count + "/10 concluídas neste navegador";
    document.querySelectorAll("[data-lesson-card]").forEach(function (card) {
      card.classList.toggle("is-done", !!data.done[card.getAttribute("data-lesson-card")]);
    });
    var go = document.getElementById("continuar");
    if (go) {
      var next = 1;
      for (var n = 1; n <= total; n++) {
        if (!data.done[String(n)]) { next = n; break; }
      }
      go.setAttribute("href", "aula" + String(next).padStart(2, "0") + ".html");
    }
    var lesson = document.body.getAttribute("data-lesson");
    var mark = document.getElementById("markDone");
    var note = document.getElementById("doneNote");
    if (mark && lesson) {
      var on = !!data.done[lesson];
      mark.textContent = on ? "Aula marcada como concluída" : "Marcar aula como concluída";
      mark.setAttribute("aria-pressed", on ? "true" : "false");
      if (note) {
        note.textContent = on
          ? "Salvo apenas neste navegador. Limpar os dados do site apaga o progresso. Não há sincronização entre aparelhos."
          : "O progresso fica só neste navegador.";
      }
    }
  }

  function bootProgress() {
    renderProgress();
    var lesson = document.body.getAttribute("data-lesson");
    var mark = document.getElementById("markDone");
    if (mark && lesson) {
      mark.addEventListener("click", function () {
        var state = load();
        if (state.done[lesson]) delete state.done[lesson];
        else state.done[lesson] = true;
        save(state);
        renderProgress();
      });
    }
    document.querySelectorAll("[data-save]").forEach(function (box) {
      var id = box.getAttribute("data-save");
      box.checked = !!load().checks[id];
      box.addEventListener("change", function () {
        var state = load();
        state.checks[id] = box.checked;
        save(state);
      });
    });
  }

  function bootReadbar() {
    var bar = document.getElementById("readbar");
    if (!bar) return;
    function onScroll() {
      var h = document.documentElement.scrollHeight - window.innerHeight;
      var p = h > 0 ? (window.scrollY / h) * 100 : 0;
      bar.style.width = Math.max(0, Math.min(100, p)) + "%";
    }
    document.addEventListener("scroll", onScroll, { passive: true });
    onScroll();
  }

  function cssVar(name, fallback) {
    var v = getComputedStyle(document.documentElement).getPropertyValue(name).trim();
    return v || fallback;
  }

  function fit(canvas) {
    var parent = canvas.parentElement;
    var w = Math.max(1, parent.clientWidth - 8);
    var h = Number(canvas.getAttribute("data-h") || 230);
    var dpr = Math.min(window.devicePixelRatio || 1, 2);
    canvas.width = Math.floor(w * dpr);
    canvas.height = Math.floor(h * dpr);
    canvas.style.width = w + "px";
    canvas.style.height = h + "px";
    var ctx = canvas.getContext("2d");
    ctx.setTransform(dpr, 0, 0, dpr, 0, 0);
    return { ctx: ctx, w: w, h: h };
  }

  function drawCharts() {
    var emerald = cssVar("--emerald", "#0f6e62");
    var neon = cssVar("--neon", "#2fcea0");
    var ink = cssVar("--ink-soft", "#2c4038");
    var line = cssVar("--line", "#d5e2db");
    var colors = [emerald, "#163a34", neon, "#7d9a90"];

    document.querySelectorAll("[data-chart]").forEach(function (host) {
      var canvas = host.querySelector("canvas");
      if (!canvas) return;
      var type = host.getAttribute("data-chart");
      var cfg;
      try { cfg = JSON.parse(host.getAttribute("data-config") || "{}"); }
      catch (e) { return; }

      function render() {
        var box = fit(canvas);
        var ctx = box.ctx;
        var w = box.w;
        var h = box.h;
        ctx.clearRect(0, 0, w, h);
        if (type === "donut") drawDonut(ctx, w, h, cfg, colors, ink);
        else if (type === "line") drawLine(ctx, w, h, cfg, [emerald, neon], ink, line);
        else drawBars(ctx, w, h, cfg, colors, ink, line);
      }
      host._render = render;
      render();
      if (!host._bound && window.ResizeObserver) {
        host._bound = true;
        new ResizeObserver(function () {
          if (host._render) host._render();
        }).observe(host);
      }
    });
  }

  function drawBars(ctx, w, h, cfg, colors, ink, line) {
    var labels = cfg.labels || [];
    var series = cfg.series || [{ name: "", data: cfg.values || [] }];
    var max = 0;
    series.forEach(function (s) { s.data.forEach(function (n) { if (n > max) max = n; }); });
    if (max <= 0) max = 1;
    var padL = 36, padB = 28, padT = 12, padR = 8;
    var innerW = w - padL - padR;
    var innerH = h - padT - padB;
    ctx.strokeStyle = line;
    ctx.lineWidth = 1;
    for (var g = 0; g <= 3; g++) {
      var y = padT + innerH - (innerH * g) / 3;
      ctx.beginPath(); ctx.moveTo(padL, y); ctx.lineTo(w - padR, y); ctx.stroke();
    }
    var groupW = innerW / Math.max(1, labels.length);
    var barW = Math.min(28, (groupW * 0.7) / series.length);
    labels.forEach(function (label, i) {
      series.forEach(function (s, si) {
        var val = Number(s.data[i] || 0);
        var bh = (val / max) * (innerH - 4);
        var x = padL + i * groupW + (groupW - barW * series.length) / 2 + si * barW;
        var y = padT + innerH - bh;
        ctx.fillStyle = colors[si % colors.length];
        ctx.beginPath();
        roundRect(ctx, x, y, Math.max(2, barW - 3), bh, 4);
        ctx.fill();
      });
      ctx.fillStyle = ink;
      ctx.font = "12px Manrope, sans-serif";
      ctx.textAlign = "center";
      ctx.fillText(String(label), padL + i * groupW + groupW / 2, h - 8);
    });
  }

  function drawLine(ctx, w, h, cfg, colors, ink, line) {
    var labels = cfg.labels || [];
    var series = cfg.series || [];
    var max = 0;
    series.forEach(function (s) { s.data.forEach(function (n) { if (n > max) max = n; }); });
    if (max <= 0) max = 1;
    var padL = 40, padB = 28, padT = 12, padR = 10;
    var innerW = w - padL - padR;
    var innerH = h - padT - padB;
    ctx.strokeStyle = line;
    for (var g = 0; g <= 3; g++) {
      var y = padT + innerH - (innerH * g) / 3;
      ctx.beginPath(); ctx.moveTo(padL, y); ctx.lineTo(w - padR, y); ctx.stroke();
    }
    series.forEach(function (s, si) {
      ctx.beginPath();
      ctx.strokeStyle = colors[si % colors.length];
      ctx.lineWidth = 2.5;
      s.data.forEach(function (n, i) {
        var x = padL + (labels.length === 1 ? innerW / 2 : (innerW * i) / (labels.length - 1));
        var y = padT + innerH - (Number(n) / max) * innerH;
        if (i === 0) ctx.moveTo(x, y); else ctx.lineTo(x, y);
      });
      ctx.stroke();
      s.data.forEach(function (n, i) {
        var x = padL + (labels.length === 1 ? innerW / 2 : (innerW * i) / (labels.length - 1));
        var y = padT + innerH - (Number(n) / max) * innerH;
        ctx.fillStyle = colors[si % colors.length];
        ctx.beginPath(); ctx.arc(x, y, 3.5, 0, Math.PI * 2); ctx.fill();
      });
    });
    ctx.fillStyle = ink;
    ctx.font = "12px Manrope, sans-serif";
    ctx.textAlign = "center";
    labels.forEach(function (label, i) {
      var x = padL + (labels.length === 1 ? innerW / 2 : (innerW * i) / (labels.length - 1));
      ctx.fillText(String(label), x, h - 8);
    });
  }

  function drawDonut(ctx, w, h, cfg, colors, ink) {
    var values = cfg.values || [];
    var total = values.reduce(function (a, b) { return a + Number(b); }, 0) || 1;
    var cx = w * 0.34;
    var cy = h * 0.52;
    var r = Math.min(w, h) * 0.32;
    var a0 = -Math.PI / 2;
    values.forEach(function (v, i) {
      var slice = (Number(v) / total) * Math.PI * 2;
      ctx.beginPath();
      ctx.moveTo(cx, cy);
      ctx.fillStyle = colors[i % colors.length];
      ctx.arc(cx, cy, r, a0, a0 + slice);
      ctx.closePath();
      ctx.fill();
      a0 += slice;
    });
    ctx.beginPath();
    ctx.fillStyle = "#ffffff";
    ctx.arc(cx, cy, r * 0.58, 0, Math.PI * 2);
    ctx.fill();
    ctx.fillStyle = ink;
    ctx.font = "700 13px Manrope, sans-serif";
    ctx.textAlign = "center";
    ctx.fillText("100%", cx, cy + 4);
    var labels = cfg.labels || [];
    ctx.textAlign = "left";
    ctx.font = "12px Manrope, sans-serif";
    labels.forEach(function (label, i) {
      var y = 28 + i * 22;
      ctx.fillStyle = colors[i % colors.length];
      ctx.fillRect(w * 0.62, y - 10, 10, 10);
      ctx.fillStyle = ink;
      ctx.fillText(label, w * 0.62 + 16, y);
    });
  }

  function roundRect(ctx, x, y, rw, rh, r) {
    var radius = Math.min(r, rw / 2, rh / 2);
    ctx.moveTo(x + radius, y);
    ctx.arcTo(x + rw, y, x + rw, y + rh, radius);
    ctx.arcTo(x + rw, y + rh, x, y + rh, radius);
    ctx.arcTo(x, y + rh, x, y, radius);
    ctx.arcTo(x, y, x + rw, y, radius);
    ctx.closePath();
  }

  function bootCopy() {
    document.querySelectorAll("[data-copy]").forEach(function (btn) {
      btn.addEventListener("click", function () {
        var wrap = btn.closest("[data-copy-wrap]");
        var pre = wrap ? wrap.querySelector("pre") : null;
        var text = pre ? pre.innerText : "";
        function done() {
          var old = btn.textContent;
          btn.textContent = "Copiado";
          setTimeout(function () { btn.textContent = old; }, 1400);
        }
        if (navigator.clipboard && navigator.clipboard.writeText) {
          navigator.clipboard.writeText(text).then(done).catch(function () { fallback(); });
        } else fallback();
        function fallback() {
          var ta = document.createElement("textarea");
          ta.value = text;
          document.body.appendChild(ta);
          ta.select();
          try { document.execCommand("copy"); done(); } catch (e) { btn.textContent = "Selecione o texto"; }
          ta.remove();
        }
      });
    });
  }

  function bootQuiz() {
    document.querySelectorAll("[data-quiz]").forEach(function (form) {
      var button = form.querySelector("[data-check]");
      if (!button) return;
      button.addEventListener("click", function () {
        var fields = form.querySelectorAll("fieldset");
        var right = 0;
        fields.forEach(function (field) {
          var expected = field.getAttribute("data-answer");
          var chosen = field.querySelector("input:checked");
          var explain = field.querySelector(".explain");
          if (explain) explain.classList.add("show");
          field.querySelectorAll("label").forEach(function (label) { label.classList.remove("ok", "bad"); });
          if (chosen && chosen.value === expected) {
            right++;
            if (chosen.parentElement) chosen.parentElement.classList.add("ok");
          } else if (chosen && chosen.parentElement) {
            chosen.parentElement.classList.add("bad");
          }
        });
        var score = form.querySelector("[data-score]");
        if (score) score.textContent = right + " de " + fields.length + " conforme o gabarito comentado abaixo de cada questão. Leia o raciocínio, não apenas a letra.";
      });
    });
  }

  function bootExercises() {
    document.querySelectorAll("[data-exercise]").forEach(function (box) {
      var btn = box.querySelector("[data-try]");
      var input = box.querySelector("input");
      var feedback = box.querySelector("[data-feedback]");
      if (!btn || !input || !feedback) return;
      btn.addEventListener("click", function () {
        var expect = num(box.getAttribute("data-expect"));
        var got = num(input.value);
        var ok = Math.abs(got - expect) < 0.05;
        feedback.textContent = ok ? feedback.getAttribute("data-ok") : feedback.getAttribute("data-bad");
        feedback.className = ok ? "ok" : "bad";
      });
    });
  }

  function bootBudget() {
    var form = document.querySelector("[data-budget]");
    if (!form) return;
    var state = load();
    if (state.budget) {
      Object.keys(state.budget).forEach(function (k) {
        var el = form.elements[k];
        if (el) el.value = state.budget[k];
      });
    }
    function calc() {
      var income = num(form.elements.renda.value);
      var keys = ["moradia", "alimentacao", "transporte", "saude", "dividas", "lazer", "outros"];
      var total = 0;
      var parts = [];
      keys.forEach(function (k) {
        var v = num(form.elements[k].value);
        total += v;
        parts.push(v);
      });
      var saldo = income - total;
      var labels = ["Moradia", "Alimentação", "Transporte", "Saúde", "Dívidas", "Lazer", "Outros"];
      var host = form.querySelector("[data-chart]");
      if (host) {
        host.setAttribute("data-config", JSON.stringify({ labels: labels, values: parts }));
        drawCharts();
      }
      var out = form.querySelector("[data-out]");
      if (out) {
        var pct = income > 0 ? Math.round((total / income) * 100) : 0;
        out.innerHTML = "<p><strong>Receita:</strong> " + money(income) + "</p>" +
          "<p><strong>Despesas:</strong> " + money(total) + " (" + pct + "% da receita)</p>" +
          "<p><strong>Saldo:</strong> " + money(saldo) + "</p>" +
          "<p>" + (saldo < 0
            ? "O saldo negativo é um aviso, não uma sentença. Separe o que é necessidade do que é desejo e veja qual compromisso cabe renegociar. Não faça uma dívida nova para “tapar” esta foto do mês."
            : saldo === 0
              ? "Tudo que entra está comprometido. Não há folga para imprevisto. O próximo passo é criar, mesmo que pequena, uma sobra intencional."
              : "Existe sobra. Decida antes de gastar: quanto vai para a reserva de imprevistos e quanto pode ir para um desejo, sem misturar os dois.") + "</p>";
      }
      var snapshot = {};
      ["renda"].concat(keys).forEach(function (k) { snapshot[k] = form.elements[k].value; });
      var data = load();
      data.budget = snapshot;
      save(data);
    }
    form.addEventListener("submit", function (e) { e.preventDefault(); calc(); });
    if (state.budget) calc();
  }

  function bootCompound() {
    var form = document.querySelector("[data-compound]");
    if (!form) return;
    form.addEventListener("submit", function (e) {
      e.preventDefault();
      var c = num(form.elements.c.value);
      var rate = num(form.elements.i.value) / 100;
      var t = Math.max(0, Math.round(num(form.elements.t.value)));
      if (t > 360) t = 360;
      var simple = c * (1 + rate * t);
      var compound = c * Math.pow(1 + rate, t);
      var rows = "";
      var sBal = c;
      var cBal = c;
      for (var m = 1; m <= t; m++) {
        sBal = c * (1 + rate * m);
        cBal = c * Math.pow(1 + rate, m);
        if (m <= 6 || m === t || m % Math.ceil(t / 6) === 0) {
          rows += "<tr><td>" + m + "</td><td>" + money(sBal) + "</td><td>" + money(cBal) + "</td><td>" + money(cBal - sBal) + "</td></tr>";
        }
      }
      var out = form.querySelector("[data-out]");
      out.innerHTML = "<p>Taxa hipotética de " + form.elements.i.value + "% ao mês, só para aprender a conta. Isso não é previsão de investimento.</p>" +
        "<p><strong>Montante com juros simples:</strong> " + money(simple) + "</p>" +
        "<p><strong>Montante com juros compostos:</strong> " + money(compound) + "</p>" +
        "<p><strong>Diferença:</strong> " + money(compound - simple) + "</p>" +
        "<div class='table-scroll'><table><thead><tr><th>Mês</th><th>Simples</th><th>Compostos</th><th>Diferença</th></tr></thead><tbody>" +
        rows + "</tbody></table></div>";
      var host = document.getElementById("compoundChart");
      if (host) {
        var labels = [];
        var simples = [];
        var compostos = [];
        var step = Math.max(1, Math.round(t / 8));
        for (var i = 0; i <= t; i += step) {
          labels.push(i === 0 ? "0" : String(i));
          simples.push(Math.round(c * (1 + rate * i)));
          compostos.push(Math.round(c * Math.pow(1 + rate, i)));
        }
        if (labels[labels.length - 1] !== String(t)) {
          labels.push(String(t));
          simples.push(Math.round(simple));
          compostos.push(Math.round(compound));
        }
        host.setAttribute("data-config", JSON.stringify({
          labels: labels,
          series: [
            { name: "Simples", data: simples },
            { name: "Compostos", data: compostos }
          ]
        }));
        drawCharts();
      }
    });
  }

  function bootProfit() {
    var form = document.querySelector("[data-profit]");
    if (!form) return;
    form.addEventListener("submit", function (e) {
      e.preventDefault();
      var price = num(form.elements.price.value);
      var qty = Math.max(0, Math.round(num(form.elements.qty.value)));
      var feePct = num(form.elements.feePct.value) / 100;
      var feeFixed = num(form.elements.feeFixed.value);
      var ads = num(form.elements.ads.value);
      var other = num(form.elements.other.value);
      var withdraw = num(form.elements.withdraw.value);
      var refunds = Math.max(0, Math.round(num(form.elements.refunds.value)));
      var sold = Math.max(0, qty - refunds);
      var gross = price * qty;
      var kept = price * sold;
      var percentFee = kept * feePct;
      var fixedFee = feeFixed * sold;
      var platform = percentFee + fixedFee;
      var profit = kept - platform - ads - other - withdraw;
      var out = form.querySelector("[data-out]");
      out.innerHTML = "<p>Simulação com os números que você digitou. Faturamento não é lucro.</p>" +
        "<p><strong>Faturamento bruto das vendas lançadas:</strong> " + money(gross) + "</p>" +
        "<p><strong>Depois de tirar reembolsos desta simulação:</strong> " + money(kept) + "</p>" +
        "<p><strong>Taxa percentual + taxa fixa sobre as vendas mantidas:</strong> " + money(platform) + "</p>" +
        "<p><strong>Anúncios + outros custos + um saque:</strong> " + money(ads + other + withdraw) + "</p>" +
        "<p><strong>Lucro estimado desta simulação:</strong> " + money(profit) + "</p>" +
        "<p>Confira na central de ajuda da Kiwify se a taxa, o saque e a regra de reembolso ainda são estes antes de tomar uma decisão. Antecipar recebível pode ter custo próprio, não incluído aqui.</p>";
      var host = document.getElementById("profitChart");
      if (host) {
        host.setAttribute("data-config", JSON.stringify({
          labels: ["Bruto", "Taxas", "Custos", "Lucro"],
          series: [{ name: "R$", data: [
            Math.round(gross),
            Math.round(platform),
            Math.round(ads + other + withdraw),
            Math.round(profit)
          ] }]
        }));
        drawCharts();
      }
    });
  }

  bootLoader();
  bootMenu();
  bootProgress();
  bootReadbar();
  drawCharts();
  bootCopy();
  bootQuiz();
  bootExercises();
  bootBudget();
  bootCompound();
  bootProfit();
})();
